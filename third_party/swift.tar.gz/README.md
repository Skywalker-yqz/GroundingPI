# ms-swift Dependency Snapshot

This package provides the ms-swift runtime used by GroundingPI. The upstream project is [ModelScope ms-swift](https://github.com/modelscope/ms-swift); the source revision and adapted files are listed in `NOTICE.release`.

## Installation

From the GroundingPI project root, use:

```bash
python3 run.py setup train
```

The project installer verifies and extracts this archive into `vendor/swift/`, then installs it with the matching dependencies. Runtime dependency versions are specified in `requirements/framework.txt`. The source includes the model and template registries, data loading and packing utilities, training code, and their supporting modules.

## Training Data

Prepare images and training caches as local files. The image loader supports local image files, local Parquet/TAR image references, bytes, data URIs and upstream HTTP(S) URLs. Parquet metadata and row-group cache sizes can be configured with `SWIFT_PARQUET_METADATA_CACHE_SIZE` and `SWIFT_PARQUET_ROWGROUP_CACHE_SIZE`.

## License

See `LICENSE` and `NOTICE.release`. Original copyright notices are retained in the source files.

## Third-party attribution for anonymous review

Names of upstream authors, companies and institutions, contact addresses,
repository namespaces, public model/dataset identifiers and example URLs in
third-party source and license notices identify their original sources. They
are retained for attribution and interoperability, not as a declaration of
this submission's authorship or affiliation. Such attribution alone does not
disclose submission authors. Original licenses and copyright notices remain
unchanged. Local adaptations are recorded separately; an unverified local
remark is not assigned to upstream merely because it is in a dependency.
