# Copyright (c) ModelScope Contributors. All rights reserved.
import os
import re
from typing import Optional, Tuple

import time as _time

import numpy as np
from datasets import load_from_disk

from swift.dataset import DatasetSyntax, data_profile_log, is_data_profile_enabled, sample_dataset
from swift.template import update_generation_config_eos_token
from swift.tuner_plugin import tuners_map
from swift.tuners import Swift
from swift.utils import get_logger

logger = get_logger()


def prepare_adapter(args, model, adapters=None):
    if args.tuner_backend == 'unsloth':
        if args.model_meta.is_multimodal:
            from unsloth import FastVisionModel as UnslothModel
        else:
            from unsloth import FastLanguageModel as UnslothModel
        UnslothModel.for_inference(model)
        return model
    if args.tuner_type in tuners_map:
        tuner = tuners_map[args.tuner_type]
    else:
        tuner = Swift
    # compat deploy
    adapters = adapters if adapters is not None else args.adapters
    for adapter in adapters:
        model = tuner.from_pretrained(model, adapter)
    if args.tuner_type == 'bone':
        # Bone has a problem of float32 matmul with bloat16 in `peft==0.14.0`
        model.to(model.dtype)
    return model


def prepare_model_template(args, **kwargs):
    adapters = kwargs.get('adapters')
    model, processor = args.get_model_processor(**kwargs)
    template = args.get_template(processor)
    if model is not None:
        if template.use_model:
            template.model = model
        model = prepare_adapter(args, model, adapters=adapters)
        if args.task_type == 'causal_lm':
            update_generation_config_eos_token(model.generation_config, template)
    return model, template


def _compute_filter_indices(dataset, max_length):
    """Return a numpy index array of rows satisfying the max_length constraint.

    Returns None when every row passes (caller can skip dataset.select entirely).
    """
    import pyarrow as pa
    import pyarrow.compute as pc

    if 'lengths' in dataset.column_names and 'length' not in dataset.column_names:
        dataset = dataset.rename_column('lengths', 'length')

    length_col = dataset.data.column('length')
    if hasattr(length_col, 'combine_chunks'):
        length_col = length_col.combine_chunks()

    effective = pc.list_max(length_col) if pa.types.is_list(length_col.type) else length_col
    effective_np = effective.to_numpy(zero_copy_only=False)
    idxs = np.where(effective_np <= max_length)[0]
    return None if len(idxs) == len(dataset) else idxs


def _select_dataset(dataset, max_length):
    if 'lengths' in dataset.column_names and 'length' not in dataset.column_names:
        dataset = dataset.rename_column('lengths', 'length')

    # Access the Arrow column directly to stay in C++ and avoid 10M Python objects.
    # For a 10M-row ASR dataset the old Python enumerate loop took ~14s; this takes <1s.
    idxs = _compute_filter_indices(dataset, max_length)

    # None means every row passes — skip the O(N) select call entirely.
    if idxs is None:
        return dataset

    new_dataset = dataset.select(idxs)
    logger.info(f'Dataset filtered, origin length: {len(dataset)}, filtered dataset length: {len(new_dataset)}')
    return new_dataset


def _get_channel_from_path(path: str) -> str:
    """Derive channel name from the last two path components."""
    parts = path.rstrip('/').split('/')
    if len(parts) >= 2:
        return '/'.join(parts[-2:])
    return parts[-1] if parts else 'unknown'


def _parse_cached_dataset_path(
    path_str: str,
) -> Tuple[str, Optional[int], Optional[float], Optional[float], Optional[float]]:
    """Parse cached dataset path with optional range and sample (same semantics as ms-swift 3.12 synth port).

    Examples:
        path/train -> full
        path/train#500000 -> sample count
        path/train#0.5 -> sample ratio in (0,1]
        path/train[0,0.7] -> row range by fraction of length
        path/train[0,0.7]#500000 -> slice then sample count
    """
    if os.path.exists(path_str):
        return path_str, None, None, None, None

    dataset_sample = None
    sample_ratio = None
    range_start = None
    range_end = None

    sample_str = None
    if '#' in path_str:
        path_str, sample_str = path_str.rsplit('#', 1)

    range_match = re.search(r'\[([0-9.]+),\s*([0-9.]+)\]\s*$', path_str)
    if range_match:
        range_start = float(range_match.group(1))
        range_end = float(range_match.group(2))
        path_str = path_str[:range_match.start()]
        assert 0 <= range_start < range_end <= 1.0, (
            f'Invalid range [{range_start},{range_end}]: must satisfy 0 <= start < end <= 1.0')

    if sample_str is not None:
        if '.' in sample_str:
            sample_ratio = float(sample_str)
            assert 0 < sample_ratio <= 1.0, f'Invalid sample ratio {sample_ratio}: must be in (0, 1.0]'
        else:
            dataset_sample = int(sample_str)

    return path_str, dataset_sample, sample_ratio, range_start, range_end


def get_cached_dataset(args):
    train_datasets, val_datasets = [], []
    random_state = np.random.RandomState(args.data_seed)
    enable_channel_loss = getattr(args, 'enable_channel_loss', False)
    _profile = is_data_profile_enabled(args)
    for cached_dataset, split_name, datasets in zip(
            [args.cached_dataset, args.cached_val_dataset],
            ['train', 'val'],
            [train_datasets, val_datasets]):
        for raw_path in cached_dataset:
            path, dataset_sample, sample_ratio, range_start, range_end = _parse_cached_dataset_path(raw_path)
            short_path = '/'.join(path.rstrip('/').split('/')[-2:])

            # ---- sub-stage 1: load_from_disk ----
            t0 = _time.monotonic()
            dataset = load_from_disk(path)
            t_load = _time.monotonic() - t0
            data_profile_log(
                f'get_cached_dataset [{split_name}] {short_path} '
                f'load_from_disk={t_load:.3f}s rows={len(dataset)}',
                args=args)

            # ---- sub-stage 2: range slice ----
            if range_start is not None and range_end is not None:
                total_len = len(dataset)
                start_idx = int(total_len * range_start)
                end_idx = int(total_len * range_end)
                t0 = _time.monotonic()
                dataset = dataset.select(range(start_idx, end_idx))
                t_slice = _time.monotonic() - t0
                logger.info(f'Range sliced [{range_start},{range_end}]: '
                            f'{total_len} -> {len(dataset)} samples (indices {start_idx}:{end_idx})')
                data_profile_log(
                    f'get_cached_dataset [{split_name}] {short_path} '
                    f'range_slice={t_slice:.3f}s rows_after={len(dataset)}',
                    args=args)

            # ---- sub-stages 3+4: max_length filter (+ optional sampling) ----
            # When both filter and sample are needed, compose the index arrays and do a
            # single dataset.select() to avoid the expensive double-index created by two
            # sequential selects (e.g. fineweb 187M→182M→500K went from ~50s to ~11s).
            rows_before_filter = len(dataset)
            needs_sample = (dataset_sample is not None or sample_ratio is not None)

            t0 = _time.monotonic()
            filter_idxs = _compute_filter_indices(dataset, args.max_length)
            t_filter_compute = _time.monotonic() - t0

            n_filtered = rows_before_filter if filter_idxs is None else len(filter_idxs)

            if sample_ratio is not None:
                dataset_sample = int(n_filtered * sample_ratio)
                logger.info(f'Ratio sampling {sample_ratio}: -> {dataset_sample} samples from {n_filtered}')

            if filter_idxs is not None and needs_sample and dataset_sample is not None:
                # Compose filter + sample into a single select to avoid double-index overhead.
                t0 = _time.monotonic()
                n_take = min(dataset_sample, n_filtered)
                if args.dataset_shuffle:
                    sample_pos = random_state.choice(n_filtered, size=n_take, replace=False)
                else:
                    sample_pos = np.arange(n_take)
                final_idxs = filter_idxs[sample_pos]
                dataset = dataset.select(final_idxs)
                t_combined = _time.monotonic() - t0
                data_profile_log(
                    f'get_cached_dataset [{split_name}] {short_path} '
                    f'filter_compute={t_filter_compute:.3f}s '
                    f'filter+sample_select={t_combined:.3f}s '
                    f'rows_before={rows_before_filter} rows_after={len(dataset)}',
                    args=args)
            else:
                # Filter-only or all-pass path.
                t0 = _time.monotonic()
                if filter_idxs is not None:
                    dataset = dataset.select(filter_idxs)
                    logger.info(
                        f'Dataset filtered, origin length: {rows_before_filter}, '
                        f'filtered dataset length: {len(dataset)}')
                t_select = _time.monotonic() - t0
                data_profile_log(
                    f'get_cached_dataset [{split_name}] {short_path} '
                    f'length_filter={t_filter_compute + t_select:.3f}s '
                    f'rows_before={rows_before_filter} rows_after={len(dataset)}',
                    args=args)

                if needs_sample and dataset_sample is not None:
                    t0 = _time.monotonic()
                    dataset = sample_dataset(
                        dataset, dataset_sample, args.dataset_shuffle,
                        random_state=random_state, shuffle_all=True)
                    t_sample = _time.monotonic() - t0
                    data_profile_log(
                        f'get_cached_dataset [{split_name}] {short_path} '
                        f'sampling={t_sample:.3f}s rows_final={len(dataset)}',
                        args=args)

            if enable_channel_loss and 'channel' not in dataset.column_names:
                channel_name = _get_channel_from_path(path)
                dataset._swift_channel = channel_name
                logger.info(f'Auto-assigned channel `{channel_name}` for cached_dataset: {path}')
            datasets.append(dataset)
    return train_datasets, val_datasets
