# Copyright (c) ModelScope Contributors. All rights reserved.
# Part of the implementation is borrowed from huggingface/transformers.
import inspect
import os
import fnmatch
import torch
from contextlib import contextmanager, nullcontext
from peft import PeftModel
from torch import nn
from torch.nn.utils.rnn import pad_sequence
from transformers import Seq2SeqTrainer as HfSeq2SeqTrainer
from transformers.models.auto.modeling_auto import MODEL_FOR_CAUSAL_LM_MAPPING_NAMES
from transformers.utils import is_peft_available
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from swift.infer_engine import InferRequest, RequestConfig, TransformersEngine
from swift.sequence_parallel import sequence_parallel
from swift.utils import HfConfigFactory, JsonlWriter, Serializer, gc_collect, get_logger, unwrap_model_for_generation
from .arguments import Seq2SeqTrainingArguments
from .mixin import DataLoaderMixin, SwiftMixin
from .utils import per_token_loss_func, per_token_loss_func_sp, shift_labels_for_causal_lm

logger = get_logger()


class Seq2SeqTrainer(SwiftMixin, DataLoaderMixin, HfSeq2SeqTrainer):
    args: Seq2SeqTrainingArguments

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.args.enable_mixed_domain_loss:
            if not self.args.enable_channel_loss:
                raise ValueError('enable_mixed_domain_loss requires enable_channel_loss=true.')
            if not self.args.text_loss_channel_patterns or not self.args.vlm_loss_channel_patterns:
                raise ValueError(
                    'enable_mixed_domain_loss requires both text_loss_channel_patterns and '
                    'vlm_loss_channel_patterns.')
        self.model_accepts_loss_kwargs = True  # fix transformers>=4.46.2
        if self.args.predict_with_generate:
            self.infer_engine = TransformersEngine(
                self.model, template=self.template, max_batch_size=self.args.per_device_eval_batch_size)
        self.jsonl_writer = JsonlWriter(os.path.join(self.args.output_dir, 'predict.jsonl'))

    @staticmethod
    def _predict_data_collator(batch):
        return {'_data': batch}

    @contextmanager
    def _patch_predict_with_generate(self):
        origin_data_collator = self.data_collator
        self.data_collator = self._predict_data_collator
        packing = self.template.packing
        padding_free = self.template.padding_free
        self.template.packing = False
        self.template.padding_free = False
        try:
            yield
        finally:
            self.template.packing = packing
            self.template.padding_free = padding_free
            self.data_collator = origin_data_collator

    def evaluate(self, *args, **kwargs):
        context = self._patch_predict_with_generate() if self.args.predict_with_generate else nullcontext()
        with context:
            res = super().evaluate(*args, **kwargs)
            gc_collect()
            return res

    def prediction_step(
        self,
        model: nn.Module,
        inputs: Dict[str, Union[torch.Tensor, Any]],
        prediction_loss_only: bool,
        ignore_keys: Optional[List[str]] = None,
        **gen_kwargs,
    ) -> Tuple[Optional[float], Optional[torch.Tensor], Optional[torch.Tensor]]:
        if not self.args.predict_with_generate or prediction_loss_only:
            with self.template.forward_context(self.model, inputs):
                return super().prediction_step(
                    model, inputs, prediction_loss_only=prediction_loss_only, ignore_keys=ignore_keys)
        data_list = inputs['_data']
        labels_list = [InferRequest.remove_response(data['messages']) for data in data_list]
        with unwrap_model_for_generation(
                self.model_wrapped, self.accelerator,
                gather_deepspeed3_params=self.args.ds3_gather_for_generation), self.template.generate_context():
            resp_list = self.infer_engine.infer(
                data_list,
                RequestConfig(max_tokens=self.model.generation_config.max_new_tokens),
                use_tqdm=False,
            )

        response_list = []
        jsonl_cache = []
        device = self.args.device
        for data, resp, labels in zip(data_list, resp_list, labels_list):
            response = resp.choices[0].message.content
            jsonl_cache.append({'response': response, 'labels': labels, **data})
            response_list.append(Serializer.to_tensor(resp.choices[0].message.content).to(device=device))
        self.jsonl_writer.append(jsonl_cache, gather_obj=True)
        labels_list = [Serializer.to_tensor(labels).to(device=device) for labels in labels_list]
        response_list = pad_sequence(response_list, batch_first=True, padding_value=0)
        labels_list = pad_sequence(labels_list, batch_first=True, padding_value=0)
        return None, response_list, labels_list

    def _prepare_inputs(self, inputs):
        args = self.args
        inputs = super()._prepare_inputs(inputs)
        if self.template.sequence_parallel_size > 1:
            sequence_parallel.prepare_inputs(inputs)

        use_logits_to_keep = self.get_use_logits_to_keep(self.template.sequence_parallel_size == 1)
        if use_logits_to_keep:
            self.prepare_logits_to_keep(inputs)
            if args.tuner_backend == 'unsloth' and isinstance(inputs['logits_to_keep'], torch.Tensor):
                inputs['logits_to_keep'] = int(inputs['logits_to_keep'].sum())

        base_model = self.template.get_base_model(self.model)
        forward_params = inspect.signature(base_model.forward).parameters
        if self.model.model_info.is_moe_model and any(key in forward_params
                                                      for key in ['output_router_logits', 'kwargs']):
            HfConfigFactory.set_config_attr(base_model.config, 'router_aux_loss_coef', args.router_aux_loss_coef)
            base_model.router_aux_loss_coef = args.router_aux_loss_coef
            logger.info_once(f'router_aux_loss_coef: {args.router_aux_loss_coef}')
            if args.router_aux_loss_coef > 0:
                inputs['output_router_logits'] = True
        inputs['compute_loss_func'] = self.compute_loss_func
        return inputs

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        labels = None
        compute_loss_func: Callable = inputs.pop('compute_loss_func', None)
        loss_scale = inputs.pop('loss_scale', None)
        text_position_ids = inputs.pop('text_position_ids', None)
        if text_position_ids is None:
            text_position_ids = inputs.get('position_ids')
        channels = inputs.pop('channel', None)
        input_ids = inputs.get('input_ids')
        attention_mask = inputs.get('attention_mask')

        if self.args.enable_mixed_domain_loss:
            input_ids = self._sanitize_text_pretrain_media_tokens(
                inputs,
                channels=channels,
                position_ids=text_position_ids,
                attention_mask=attention_mask,
            )

        if (self.label_smoother is not None or compute_loss_func is not None or loss_scale is not None
                or self.args.enable_dft_loss or self.args.enable_channel_loss or self.args.enable_mixed_domain_loss
                or self.template.sequence_parallel_size > 1) and 'labels' in inputs:
            if self.args.use_liger_kernel:
                logger.warning_once('The cross_entropy loss function defined in Liger Kernel will not '
                                    'take effect, potentially leading to increased GPU memory consumption.')
            labels = inputs.get('labels')
        outputs = model(**inputs)
        if isinstance(outputs, dict):
            model_loss = outputs.get('loss')
        else:
            model_loss = getattr(outputs, 'loss', None)
        if getattr(outputs, 'aux_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['aux_loss'].update(outputs.aux_loss)
        if model_loss is not None:
            mode = 'train' if self.model.training else 'eval'
            _model_loss_log = model_loss.detach() if isinstance(model_loss, torch.Tensor) else model_loss
            self.custom_metrics[mode]['loss'].update(_model_loss_log)
        if getattr(outputs, 'backprop_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['backprop_loss'].update(
                outputs.backprop_loss.detach() if isinstance(outputs.backprop_loss, torch.Tensor) else outputs.backprop_loss)
        if getattr(outputs, 'total_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['total_loss'].update(
                outputs.total_loss.detach() if isinstance(outputs.total_loss, torch.Tensor) else outputs.total_loss)
        if getattr(outputs, 'lm_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            _lm_loss_log = outputs.lm_loss.detach() if isinstance(outputs.lm_loss, torch.Tensor) else outputs.lm_loss
            self.custom_metrics[mode]['lm_loss'].update(_lm_loss_log)
        if getattr(outputs, 'mtp_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['mtp_loss'].update(
                outputs.mtp_loss.detach() if isinstance(outputs.mtp_loss, torch.Tensor) else outputs.mtp_loss)
        # Record optional text, audio, and per-head MTP losses returned by the model.
        if getattr(outputs, 'mtp_text_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['mtp_text_loss'].update(
                outputs.mtp_text_loss.detach()
                if isinstance(outputs.mtp_text_loss, torch.Tensor) else outputs.mtp_text_loss)
        if getattr(outputs, 'mtp_audio_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['mtp_audio_loss'].update(
                outputs.mtp_audio_loss.detach()
                if isinstance(outputs.mtp_audio_loss, torch.Tensor) else outputs.mtp_audio_loss)
        if getattr(outputs, 'mtp_text_head_losses', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            _th = outputs.mtp_text_head_losses
            if isinstance(_th, torch.Tensor) and _th.ndim >= 1:
                for _i in range(_th.shape[0]):
                    self.custom_metrics[mode][f'mtp_text_head{_i}_loss'].update(_th[_i].detach())
        if getattr(outputs, 'mtp_audio_head_losses', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            _ah = outputs.mtp_audio_head_losses
            if isinstance(_ah, torch.Tensor) and _ah.ndim >= 1:
                for _i in range(_ah.shape[0]):
                    self.custom_metrics[mode][f'mtp_audio_head{_i}_loss'].update(_ah[_i].detach())


        # Record optional MTP KL distillation losses.
        if getattr(outputs, 'mtp_kl_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['mtp_kl_loss'].update(
                outputs.mtp_kl_loss.detach()
                if isinstance(outputs.mtp_kl_loss, torch.Tensor) else outputs.mtp_kl_loss)
        if getattr(outputs, 'mtp_kl_head_losses', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            _kh = outputs.mtp_kl_head_losses
            if isinstance(_kh, torch.Tensor) and _kh.ndim >= 1:
                for _i in range(_kh.shape[0]):
                    self.custom_metrics[mode][f'mtp_kl_head{_i}_loss'].update(_kh[_i].detach())

        if getattr(outputs, 'kd_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['kd_loss'].update(outputs.kd_loss.detach() if isinstance(outputs.kd_loss, torch.Tensor) else outputs.kd_loss)
        if getattr(outputs, 'kd_mse_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['kd_mse_loss'].update(
                outputs.kd_mse_loss.detach() if isinstance(outputs.kd_mse_loss, torch.Tensor) else outputs.kd_mse_loss)
        if getattr(outputs, 'kd_cos_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['kd_cos_loss'].update(
                outputs.kd_cos_loss.detach() if isinstance(outputs.kd_cos_loss, torch.Tensor) else outputs.kd_cos_loss)
        if getattr(outputs, 'combined_kd_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['combined_kd_loss'].update(
                outputs.combined_kd_loss.detach() if isinstance(outputs.combined_kd_loss, torch.Tensor) else outputs.combined_kd_loss)
        if getattr(outputs, 'adapter_kd_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['adapter_kd_loss'].update(
                outputs.adapter_kd_loss.detach() if isinstance(outputs.adapter_kd_loss, torch.Tensor) else outputs.adapter_kd_loss)
        if getattr(outputs, 'adapter_kd_mse_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['adapter_kd_mse_loss'].update(
                outputs.adapter_kd_mse_loss.detach() if isinstance(outputs.adapter_kd_mse_loss, torch.Tensor) else outputs.adapter_kd_mse_loss)
        if getattr(outputs, 'adapter_kd_cos_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['adapter_kd_cos_loss'].update(
                outputs.adapter_kd_cos_loss.detach() if isinstance(outputs.adapter_kd_cos_loss, torch.Tensor) else outputs.adapter_kd_cos_loss)
        if getattr(outputs, 'observe_ce_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['observe_ce_loss'].update(
                outputs.observe_ce_loss.detach() if isinstance(outputs.observe_ce_loss, torch.Tensor) else outputs.observe_ce_loss)
        qwen3vl_kd_metric_names = [
            'final_embed_kd_loss',
            'final_embed_kd_mse_loss',
            'final_embed_kd_cos_loss',
            'deepstack_kd_loss',
            'deepstack_kd_mse_loss',
            'deepstack_kd_cos_loss',
            'llm_early_hidden_kd_loss',
            'llm_early_hidden_kd_mse_loss',
            'llm_early_hidden_kd_cos_loss',
            'logits_kd_loss',
        ]
        for metric_name in qwen3vl_kd_metric_names:
            metric_value = getattr(outputs, metric_name, None)
            if metric_value is None:
                continue
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode][metric_name].update(
                metric_value.detach() if isinstance(metric_value, torch.Tensor) else metric_value)
        if getattr(outputs, 'text_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['text_loss'].update(outputs.text_loss)
        if getattr(outputs, 'audio_loss', None) is not None:
            mode = 'train' if self.model.training else 'eval'
            self.custom_metrics[mode]['audio_loss'].update(outputs.audio_loss)
        # Save past state if it exists
        # TODO: this needs to be fixed and made cleaner later.
        if hasattr(self.args, 'past_index') and self.args.past_index >= 0:
            self._past = outputs[self.args.past_index]

        if labels is None:
            labels = inputs['labels']
            outputs.loss = outputs.loss.to(labels.device)
            # fix https://github.com/huggingface/transformers/issues/34263
            if num_items_in_batch is not None:
                outputs.loss = outputs.loss * ((labels[:, 1:] != -100).sum() / num_items_in_batch)

            if isinstance(outputs, dict) and 'loss' not in outputs:
                raise ValueError(
                    'The model did not return a loss from the inputs, only the following keys: '
                    f"{','.join(outputs.keys())}. For reference, the inputs it received are {','.join(inputs.keys())}.")
            # We don't use .loss here since the model may return tuples instead of ModelOutput.
            loss = outputs['loss'] if isinstance(outputs, dict) else outputs[0]
        else:
            use_forward_loss = (self.label_smoother is None and compute_loss_func is None and loss_scale is None
                                and not self.args.enable_dft_loss and self.template.sequence_parallel_size == 1)
            outputs.loss = None
            if (self.args.enable_dft_loss or loss_scale is not None or self.args.enable_channel_loss
                    or self.template.sequence_parallel_size > 1):
                if self.template.sequence_parallel_size > 1:
                    outputs.loss = per_token_loss_func_sp(outputs, labels, enable_dft_loss=self.args.enable_dft_loss)
                else:
                    outputs.loss = per_token_loss_func(outputs, labels, enable_dft_loss=self.args.enable_dft_loss)

                if loss_scale is not None:
                    loss_scale = torch.roll(loss_scale, shifts=-1, dims=-1)
                    if loss_scale.shape[-1] > 0:
                        loss_scale[..., -1] = 0
                    loss_scale = loss_scale.reshape(-1)
                    outputs.loss = outputs.loss * loss_scale

                if (self.args.enable_channel_loss and not self.args.enable_mixed_domain_loss
                        and channels is not None):
                    mode = 'train' if self.model.training else 'eval'
                    metrics = self.custom_metrics[mode]
                    masks = shift_labels_for_causal_lm(labels).reshape(-1) != -100
                    channel_loss_pt = outputs.loss.detach()
                    # Channel loss is main LM/NTP per-token CE only.
                    # MTP losses are reported exclusively through mtp_* metrics.
                    if self.template.padding_free:
                        cu_seqlens = self.get_cu_seqlens(text_position_ids, inputs.get('logits_to_keep'))
                    else:
                        cu_seqlens = torch.arange(0, labels.shape[0] + 1) * labels.shape[1]
                    for i in range(cu_seqlens.shape[0] - 1):
                        channel = channels[i]
                        slice_ = slice(cu_seqlens[i], cu_seqlens[i + 1])
                        metrics[f'loss_{channel}'].update(channel_loss_pt[slice_][masks[slice_]])

            unwrapped_model = self.accelerator.unwrap_model(model)
            if is_peft_available() and isinstance(unwrapped_model, PeftModel):
                model_name = unwrapped_model.model._get_name()
            else:
                model_name = unwrapped_model._get_name()
            # User-defined compute_loss function
            if self.args.enable_mixed_domain_loss:
                loss = self._compute_mixed_domain_loss(
                    outputs,
                    labels,
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=text_position_ids,
                    channels=channels,
                )
            elif compute_loss_func is not None:
                loss = compute_loss_func(
                    outputs, labels, num_items_in_batch=num_items_in_batch, loss_scale=loss_scale, trainer=self)
            elif self.label_smoother is None:
                if use_forward_loss:
                    if model_loss is None:
                        raise ValueError(
                            'The model did not return a loss in use_forward_loss mode. '
                            f'Input keys: {",".join(inputs.keys())}.')
                    loss = model_loss.to(labels.device)
                    if num_items_in_batch is not None:
                        loss = loss * ((labels[:, 1:] != -100).sum() / num_items_in_batch)
                else:
                    if num_items_in_batch is None:
                        num_items_in_batch = (labels[:, 1:] != -100).sum()
                    loss = outputs.loss.sum() / num_items_in_batch
            else:
                if model_name in MODEL_FOR_CAUSAL_LM_MAPPING_NAMES.values():
                    loss = self.label_smoother(outputs, labels, shift_labels=True)
                else:
                    loss = self.label_smoother(outputs, labels)

            if self.model.model_info.is_moe_model and self.args.router_aux_loss_coef is not None:
                aux_loss = outputs.get('aux_loss')
                if aux_loss is not None:
                    if num_items_in_batch is not None:
                        aux_loss = aux_loss * ((labels[:, 1:] != -100).sum() / num_items_in_batch)
                    loss = loss + self.args.router_aux_loss_coef * aux_loss.to(loss.device)

            if not use_forward_loss:
                if getattr(outputs, 'mtp_loss', None) is not None:
                    if isinstance(outputs.mtp_loss, torch.Tensor) and outputs.mtp_loss.requires_grad:
                        mtp_to_add = outputs.mtp_loss
                        if num_items_in_batch is not None:
                            mtp_to_add = mtp_to_add * ((labels[:, 1:] != -100).sum() / num_items_in_batch)
                        loss = loss + mtp_to_add

            if isinstance(loss, torch.Tensor) and not loss.requires_grad:
                recovered_terms = []
                if model_loss is not None and isinstance(model_loss, torch.Tensor) and model_loss.requires_grad:
                    recovered_terms.append(model_loss.to(labels.device))
                kd_weight = float(inputs.get('kd_weight', 0.0) or 0.0)
                if getattr(outputs, 'kd_loss', None) is not None and isinstance(outputs.kd_loss, torch.Tensor) and outputs.kd_loss.requires_grad and kd_weight > 0.0:
                    recovered_terms.append(kd_weight * outputs.kd_loss)
                if recovered_terms:
                    recovered_loss = recovered_terms[0]
                    for extra_term in recovered_terms[1:]:
                        recovered_loss = recovered_loss + extra_term
                    logger.warning_once('Recovered detached training loss from differentiable KD terms.')
                    loss = recovered_loss

        if isinstance(loss, torch.Tensor) and not loss.requires_grad:
            recovered_terms = []
            loss_device = None
            if labels is not None and isinstance(labels, torch.Tensor):
                loss_device = labels.device
            elif getattr(outputs, 'logits', None) is not None and isinstance(outputs.logits, torch.Tensor):
                loss_device = outputs.logits.device
            if model_loss is not None and isinstance(model_loss, torch.Tensor) and model_loss.requires_grad:
                recovered_terms.append(model_loss.to(loss_device) if loss_device is not None else model_loss)
            kd_weight = float(inputs.get('kd_weight', 0.0) or 0.0)
            if getattr(outputs, 'kd_loss', None) is not None and isinstance(outputs.kd_loss, torch.Tensor) and outputs.kd_loss.requires_grad and kd_weight > 0.0:
                recovered_terms.append(kd_weight * outputs.kd_loss)
            if recovered_terms:
                recovered_loss = recovered_terms[0]
                for extra_term in recovered_terms[1:]:
                    recovered_loss = recovered_loss + extra_term
                logger.warning_once('Recovered detached training loss from differentiable KD terms.')
                loss = recovered_loss

        if self.model.training and isinstance(loss, torch.Tensor) and not loss.requires_grad:
            surrogate_loss = None
            for parameter in model.parameters():
                if parameter.requires_grad:
                    surrogate_loss = parameter.sum() * 0
                    break
            if surrogate_loss is not None:
                logger.warning_once(
                    'Detached loss without trainable-path gradients detected; using a zero-gradient surrogate so '
                    'adapter-only multimodal runs can skip text-only or invalid-image batches.'
                )
                loss = surrogate_loss + loss.detach().to(surrogate_loss.device) * 0

        if getattr(self.args, 'average_tokens_across_devices',
                   False) and self.model_accepts_loss_kwargs and num_items_in_batch is not None:
            loss *= self.accelerator.num_processes

        if (outputs.logits is not None and labels is not None and self.args.tuner_backend != 'unsloth'):
            cu_seqlens = None
            if self.template.padding_free and self.args.acc_strategy == 'seq':
                cu_seqlens = self.get_cu_seqlens(text_position_ids, inputs.get('logits_to_keep'))
            # Liger does not have logits
            # Unsloth has a bug with output logits
            self._compute_acc(outputs, labels, cu_seqlens=cu_seqlens)
        return (loss, outputs) if return_outputs else loss

    @staticmethod
    def _parse_channel_patterns(patterns: str) -> List[str]:
        return [pattern.strip() for pattern in patterns.split(',') if pattern.strip()]

    @staticmethod
    def _normalize_channel_rows(channels, batch_size: int) -> List[List[str]]:
        if isinstance(channels, str):
            return [[channels]]
        if not isinstance(channels, (list, tuple)):
            raise ValueError(f'Mixed-domain loss requires channel metadata, got: {type(channels).__name__}.')
        if batch_size == 1 and all(isinstance(channel, str) for channel in channels):
            return [list(channels)]
        if len(channels) != batch_size:
            raise ValueError(f'Channel rows ({len(channels)}) do not match batch size ({batch_size}).')
        return [list(row) if isinstance(row, (list, tuple)) else [row] for row in channels]

    def _sanitize_text_pretrain_media_tokens(self,
                                             inputs,
                                             *,
                                             channels,
                                             position_ids: Optional[torch.Tensor],
                                             attention_mask: Optional[torch.Tensor]) -> Optional[torch.Tensor]:
        """Prevent reserved media placeholders in raw text from consuming VLM features."""
        input_ids = inputs.get('input_ids')
        if input_ids is None or position_ids is None or channels is None:
            return input_ids

        input_ids_2d = input_ids.unsqueeze(0) if input_ids.ndim == 1 else input_ids
        if position_ids.ndim == 3:
            position_ids_2d = position_ids[:, 0, :]
        elif position_ids.ndim == 1:
            position_ids_2d = position_ids.unsqueeze(0)
        else:
            position_ids_2d = position_ids
        if attention_mask is None:
            valid_tokens = torch.ones_like(input_ids_2d, dtype=torch.bool)
        else:
            attention_mask_2d = attention_mask.unsqueeze(0) if attention_mask.ndim == 1 else attention_mask
            valid_tokens = attention_mask_2d.to(dtype=torch.bool)

        channel_rows = self._normalize_channel_rows(channels, input_ids_2d.shape[0])
        text_patterns = self._parse_channel_patterns(self.args.text_loss_channel_patterns)
        text_domains = torch.zeros_like(input_ids_2d, dtype=torch.bool)
        for row_idx, row_channels in enumerate(channel_rows):
            valid_length = int(valid_tokens[row_idx].sum().item())
            starts = torch.nonzero(
                position_ids_2d[row_idx, :valid_length] == 0, as_tuple=False).flatten().tolist()
            if len(starts) != len(row_channels):
                raise ValueError(
                    f'Packed channel/segment mismatch before model forward at row {row_idx}: '
                    f'channels={len(row_channels)}, position_resets={len(starts)}, channel_values={row_channels}.')
            ends = starts[1:] + [valid_length]
            for channel, start, end in zip(row_channels, starts, ends):
                if any(fnmatch.fnmatch(channel, pattern) for pattern in text_patterns):
                    text_domains[row_idx, start:end] = True

        tokenizer = self.template.processor.tokenizer
        image_token_id = tokenizer.convert_tokens_to_ids('<|image_pad|>')
        video_token_id = tokenizer.convert_tokens_to_ids('<|video_pad|>')
        replacement_token_id = tokenizer.convert_tokens_to_ids('<|vision_pad|>')
        if not all(isinstance(token_id, int) and token_id >= 0
                   for token_id in (image_token_id, video_token_id, replacement_token_id)):
            raise ValueError('Tokenizer is missing required vision placeholder token ids.')

        media_mask = text_domains & (
            (input_ids_2d == image_token_id) | (input_ids_2d == video_token_id))
        media_count = int(media_mask.sum().item())
        if media_count == 0:
            return input_ids

        sanitized_ids_2d = input_ids_2d.clone()
        sanitized_ids_2d[media_mask] = replacement_token_id
        sanitized_ids = sanitized_ids_2d.squeeze(0) if input_ids.ndim == 1 else sanitized_ids_2d
        inputs['input_ids'] = sanitized_ids

        labels = inputs.get('labels')
        if isinstance(labels, torch.Tensor) and labels.shape == input_ids.shape:
            labels_2d = labels.unsqueeze(0) if labels.ndim == 1 else labels
            sanitized_labels_2d = labels_2d.clone()
            label_media_mask = media_mask & (
                (labels_2d == image_token_id) | (labels_2d == video_token_id))
            sanitized_labels_2d[label_media_mask] = replacement_token_id
            inputs['labels'] = sanitized_labels_2d.squeeze(0) if labels.ndim == 1 else sanitized_labels_2d

        logger.warning(
            'Sanitized %d reserved media placeholder token(s) inside text-pretrain packed segments; '
            'VLM media placeholders were left unchanged.', media_count)
        return sanitized_ids

    @staticmethod
    def _distributed_mean_loss(local_losses: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        local_sum = local_losses.sum()
        global_count = local_sum.new_tensor(float(local_losses.numel()))
        global_sum = local_sum.detach().clone()
        world_size = 1
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            torch.distributed.all_reduce(global_count)
            torch.distributed.all_reduce(global_sum)
            world_size = torch.distributed.get_world_size()
        if global_count.item() == 0:
            return local_sum * 0., global_sum * 0., global_count
        # DDP averages gradients, so compensate when normalizing by a global token count.
        train_loss = local_sum * world_size / global_count
        metric = global_sum / global_count
        return train_loss, metric, global_count

    def _mixed_domain_visual_zero_anchor(self) -> Optional[torch.Tensor]:
        """Keep ZeRO gradient collectives identical on text-only and VLM ranks."""
        model = self.model
        while hasattr(model, 'module'):
            model = model.module
        visual = getattr(getattr(model, 'model', None), 'visual', None)
        if visual is None:
            return None

        anchor = None
        for parameter in visual.parameters():
            if parameter.requires_grad:
                zero = parameter.reshape(-1)[0] * 0.
                anchor = zero if anchor is None else anchor + zero
        return anchor

    def _compute_mixed_domain_loss(self,
                                   outputs,
                                   assistant_labels: torch.Tensor,
                                   *,
                                   input_ids: torch.Tensor,
                                   attention_mask: Optional[torch.Tensor],
                                   position_ids: Optional[torch.Tensor],
                                   channels) -> torch.Tensor:
        if input_ids is None or position_ids is None:
            raise ValueError('Mixed-domain loss requires input_ids and position_ids.')
        if position_ids.ndim == 3:
            position_ids = position_ids[:, 0, :]
        elif position_ids.ndim == 1:
            position_ids = position_ids.unsqueeze(0)
        if input_ids.ndim == 1:
            input_ids = input_ids.unsqueeze(0)
        if attention_mask is None:
            valid_tokens = torch.ones_like(input_ids, dtype=torch.bool)
        else:
            if attention_mask.ndim == 1:
                attention_mask = attention_mask.unsqueeze(0)
            valid_tokens = attention_mask.to(dtype=torch.bool)

        channel_rows = self._normalize_channel_rows(channels, input_ids.shape[0])
        text_patterns = self._parse_channel_patterns(self.args.text_loss_channel_patterns)
        vlm_patterns = self._parse_channel_patterns(self.args.vlm_loss_channel_patterns)
        text_domains = torch.zeros_like(input_ids, dtype=torch.bool)
        vlm_domains = torch.zeros_like(input_ids, dtype=torch.bool)

        for row_idx, row_channels in enumerate(channel_rows):
            valid_length = int(valid_tokens[row_idx].sum().item())
            starts = torch.nonzero(
                position_ids[row_idx, :valid_length] == 0, as_tuple=False).flatten().tolist()
            if len(starts) != len(row_channels):
                raise ValueError(
                    f'Packed channel/segment mismatch at row {row_idx}: channels={len(row_channels)}, '
                    f'position_resets={len(starts)}, channel_values={row_channels}.')
            ends = starts[1:] + [valid_length]
            for channel, start, end in zip(row_channels, starts, ends):
                is_text = any(fnmatch.fnmatch(channel, pattern) for pattern in text_patterns)
                is_vlm = any(fnmatch.fnmatch(channel, pattern) for pattern in vlm_patterns)
                if is_text == is_vlm:
                    raise ValueError(
                        f'Channel must match exactly one mixed-loss domain: channel={channel!r}, '
                        f'text_patterns={text_patterns}, vlm_patterns={vlm_patterns}.')
                (text_domains if is_text else vlm_domains)[row_idx, start:end] = True

        full_labels = input_ids.clone()
        full_labels[~valid_tokens] = -100
        # Packed segments are independent causal sequences. Mask each segment's first target.
        full_labels[position_ids == 0] = -100
        text_loss_pt = per_token_loss_func(outputs, full_labels)
        shifted_full_labels = shift_labels_for_causal_lm(full_labels).reshape(-1)
        text_valid = text_domains.reshape(-1) & (shifted_full_labels != -100)

        shifted_assistant_labels = shift_labels_for_causal_lm(assistant_labels).reshape(-1)
        vlm_valid = vlm_domains.reshape(-1) & (shifted_assistant_labels != -100)
        text_loss, text_metric, text_count = self._distributed_mean_loss(text_loss_pt[text_valid])
        vlm_loss, vlm_metric, vlm_count = self._distributed_mean_loss(outputs.loss[vlm_valid])

        mode = 'train' if self.model.training else 'eval'
        self.custom_metrics[mode]['text_loss'].update(text_metric)
        self.custom_metrics[mode]['vlm_loss'].update(vlm_metric)
        self.custom_metrics[mode]['text_loss_tokens'].update(text_count)
        self.custom_metrics[mode]['vlm_loss_tokens'].update(vlm_count)
        loss = text_loss + vlm_loss
        visual_zero_anchor = self._mixed_domain_visual_zero_anchor()
        if visual_zero_anchor is not None:
            loss = loss + visual_zero_anchor
        return loss

    def training_step(self, model, inputs, *args, **kwargs):
        with self.template.forward_context(self.model, inputs):
            return super().training_step(model, inputs, *args, **kwargs)
