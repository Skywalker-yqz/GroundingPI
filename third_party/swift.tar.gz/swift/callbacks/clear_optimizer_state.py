# Copyright (c) ModelScope Contributors. All rights reserved.

import glob
import os
import shutil
from typing import List

from swift.utils import get_logger, is_master
from .base import TrainerCallback

logger = get_logger()


class ClearOptimizerStateCallback(TrainerCallback):
    """
    After training finishes, remove optimizer/scheduler/random-state artifacts inside existing checkpoints.

    This is intended for "二次清理" 场景:
    - resume 阶段仍可正常读取 optimizer 等训练状态
    - 但训练正常结束后，释放磁盘空间，只保留模型权重与必要元数据

    The implementation targets HuggingFace-style checkpoints that store:
    - optimizer.pt
    - scheduler.pt
    - rng_state.pth / rng_state_<rank>.pth

    DeepSpeed ZeRO may place shards under subdirs (e.g. ``checkpoint-*/global_step*/*_optim_states.pt``);
    those are matched with recursive globs.
    """

    # Keep file names minimal to avoid accidental deletion.
    DEFAULT_REMOVE_FILES = [
        'optimizer.pt',
        'scheduler.pt',
        'rng_state.pth',
    ]
    DEFAULT_REMOVE_GLOBS = [
        'rng_state_*.pth',
        # Deepspeed ZeRO checkpoint optimizer states
        # Example: bf16_zero_pp_rank_0_mp_rank_0_optim_states.pt
        '*_optim_states.pt',
        '*optim_states.pt',
    ]

    MEGATRON_ITER_PREFIX = 'iter_'
    MEGATRON_STATE_TOKENS = ('optimizer', 'opt_param_scheduler', 'rng_state')

    def __init__(self, args, trainer):
        super().__init__(args, trainer)

    def _remove_if_exists(self, path: str) -> bool:
        try:
            if os.path.exists(path):
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
                return True
        except Exception as e:
            logger.warning(f'Failed to remove {path}: {e}')
        return False

    def _maybe_clear_megatron_iter_dir(self, iter_dir: str) -> List[str]:
        """
        Megatron mcore checkpoint layout is stored under iter_{iteration}/
        and saved via torch.distributed checkpointing.

        We use heuristic cleanup:
        - Remove directories/files that explicitly match optimizer/scheduler/rng keys.
        - Remove any file/dir whose basename contains optimizer/opt_param_scheduler/rng_state tokens.

        This is designed to work with common distcp output layouts, but since
        the exact filenames depend on PyTorch/Megatron versions, it is not
        guaranteed to be perfect in all environments.
        """
        removed: List[str] = []
        if not os.path.isdir(iter_dir):
            return removed

        # Common direct children (if present).
        direct_names = ['optimizer', 'opt_param_scheduler', 'rng_state']
        for name in direct_names:
            removed_path = os.path.join(iter_dir, name)
            if self._remove_if_exists(removed_path):
                removed.append(removed_path)

        # Token-based cleanup (conservative: only match basename).
        for token in self.MEGATRON_STATE_TOKENS:
            for path in glob.glob(os.path.join(iter_dir, f'*{token}*')):
                base = os.path.basename(path)
                if 'model' in base:
                    continue
                if self._remove_if_exists(path):
                    removed.append(path)
        return removed

    def on_train_end(self, args, state, control, **kwargs):
        if not is_master():
            return

        output_dir = getattr(args, 'output_dir', None)
        if not output_dir:
            return

        pattern = os.path.join(output_dir, 'checkpoint-*')
        ckpt_dirs = [
            d for d in glob.glob(pattern)
            if os.path.isdir(d) and os.path.basename(d).startswith('checkpoint-')
        ]
        if not ckpt_dirs:
            return

        removed_files: List[str] = []

        for ckpt_dir in ckpt_dirs:
            # Exact names at checkpoint root (HF default)
            for fname in self.DEFAULT_REMOVE_FILES:
                top = os.path.join(ckpt_dir, fname)
                if self._remove_if_exists(top):
                    removed_files.append(top)

            # Subdirs e.g. DeepSpeed ZeRO: checkpoint-90/global_step90/bf16_zero_*_optim_states.pt
            for fname in self.DEFAULT_REMOVE_FILES:
                for fpath in glob.glob(os.path.join(ckpt_dir, '**', fname), recursive=True):
                    if self._remove_if_exists(fpath):
                        removed_files.append(fpath)

            for g in self.DEFAULT_REMOVE_GLOBS:
                for fpath in glob.glob(os.path.join(ckpt_dir, '**', g), recursive=True):
                    if self._remove_if_exists(fpath):
                        removed_files.append(fpath)

        # Megatron mcore checkpoints store state under iter_* directories.
        # Common layout:
        #   output_dir/checkpoint-<step>/iter_<step>/...
        # but depending on trainer/config, iter_* may be nested, so we search recursively.
        iter_glob = os.path.join(output_dir, '**', f'{self.MEGATRON_ITER_PREFIX}*')
        iter_dirs = [
            p for p in glob.glob(iter_glob, recursive=True)
            if os.path.isdir(p)
        ]
        megatron_removed = []
        for iter_dir in iter_dirs:
            megatron_removed.extend(self._maybe_clear_megatron_iter_dir(iter_dir))

        removed_files.extend(megatron_removed)

        if removed_files:
            logger.info(
                f'Cleared optimizer-related states from {len(removed_files)} files/dirs in checkpoints (HF + Megatron).')

