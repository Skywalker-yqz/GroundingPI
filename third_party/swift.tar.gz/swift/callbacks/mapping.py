# Copyright (c) ModelScope Contributors. All rights reserved.
from .activation_cpu_offload import ActivationCpuOffloadCallBack
from .adalora import AdaloraCallback
from .deepspeed_elastic import DeepspeedElasticCallback, GracefulExitCallback
from .early_stop import EarlyStopCallback
from .lisa import LISACallback
from .clear_optimizer_state import ClearOptimizerStateCallback
from .perf_log import PerfMetricsLogCallback

callbacks_map = {
    'activation_cpu_offload': ActivationCpuOffloadCallBack,
    'adalora': AdaloraCallback,
    'deepspeed_elastic': DeepspeedElasticCallback,
    'early_stop': EarlyStopCallback,
    'graceful_exit': GracefulExitCallback,
    'lisa': LISACallback,
    'clear_optimizer_state': ClearOptimizerStateCallback,
    'perf_log': PerfMetricsLogCallback
}
