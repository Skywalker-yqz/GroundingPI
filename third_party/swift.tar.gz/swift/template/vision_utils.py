# Copyright (c) ModelScope Contributors. All rights reserved.
import base64
import bisect
import math
import threading
import numpy as np
import os
import re
import requests
import torch
from collections import Counter, OrderedDict
from functools import lru_cache
from io import BytesIO
from PIL import Image
from requests.adapters import HTTPAdapter
from typing import Any, Callable, List, TypeVar, Union
from urllib.parse import parse_qs
from urllib3.util.retry import Retry

from swift.utils import get_env_args

# >>> internvl
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def _build_transform(input_size):
    import torchvision.transforms as T
    from torchvision.transforms.functional import InterpolationMode
    MEAN, STD = IMAGENET_MEAN, IMAGENET_STD
    transform = T.Compose([
        T.Lambda(lambda img: img.convert('RGB') if img.mode != 'RGB' else img),
        T.Resize((input_size, input_size), interpolation=InterpolationMode.BICUBIC),
        T.ToTensor(),
        T.Normalize(mean=MEAN, std=STD)
    ])
    return transform


def _find_closest_aspect_ratio(aspect_ratio, target_ratios, width, height, image_size):
    best_ratio_diff = float('inf')
    best_ratio = (1, 1)
    area = width * height
    for ratio in target_ratios:
        target_aspect_ratio = ratio[0] / ratio[1]
        ratio_diff = abs(aspect_ratio - target_aspect_ratio)
        if ratio_diff < best_ratio_diff:
            best_ratio_diff = ratio_diff
            best_ratio = ratio
        elif ratio_diff == best_ratio_diff:
            if area > 0.5 * image_size * image_size * ratio[0] * ratio[1]:
                best_ratio = ratio
    return best_ratio


def _dynamic_preprocess(image, min_num=1, max_num=12, image_size=448, use_thumbnail=False):
    orig_width, orig_height = image.size
    aspect_ratio = orig_width / orig_height

    # calculate the existing image aspect ratio
    target_ratios = set((i, j) for n in range(min_num, max_num + 1) for i in range(1, n + 1) for j in range(1, n + 1)
                        if min_num <= i * j <= max_num)
    target_ratios = sorted(target_ratios, key=lambda x: x[0] * x[1])

    # find the closest aspect ratio to the target
    target_aspect_ratio = _find_closest_aspect_ratio(aspect_ratio, target_ratios, orig_width, orig_height, image_size)

    # calculate the target width and height
    target_width = image_size * target_aspect_ratio[0]
    target_height = image_size * target_aspect_ratio[1]
    blocks = target_aspect_ratio[0] * target_aspect_ratio[1]

    # resize the image
    resized_img = image.resize((target_width, target_height))
    processed_images = []
    for i in range(blocks):
        box = ((i % (target_width // image_size)) * image_size, (i // (target_width // image_size)) * image_size,
               ((i % (target_width // image_size)) + 1) * image_size, ((i //
                                                                        (target_width // image_size)) + 1) * image_size)
        # split the image
        split_img = resized_img.crop(box)
        processed_images.append(split_img)
    assert len(processed_images) == blocks
    if use_thumbnail and len(processed_images) != 1:
        thumbnail_img = image.resize((image_size, image_size))
        processed_images.append(thumbnail_img)
    return processed_images


# <<< internvl


def rescale_image(img: Image.Image, max_pixels: int) -> Image.Image:
    import torchvision.transforms as T
    width = img.width
    height = img.height
    if max_pixels is None or max_pixels <= 0 or width * height <= max_pixels:
        return img

    ratio = width / height
    height_scaled = math.sqrt(max_pixels / ratio)
    width_scaled = height_scaled * ratio
    return T.Resize((int(height_scaled), int(width_scaled)))(img)


_T = TypeVar('_T')


def _check_path(path: str) -> Union[str, None]:
    """If it is a path, return the string; if it is base64, return None."""
    MAX_PATH_HEURISTIC = 2000
    if len(path) > MAX_PATH_HEURISTIC:
        return
    if os.path.exists(path):
        return os.path.abspath(path)
    data = path
    ROOT_IMAGE_DIR = get_env_args('ROOT_IMAGE_DIR', str, None)
    if ROOT_IMAGE_DIR is not None:
        path = os.path.join(ROOT_IMAGE_DIR, path)
    path = os.path.abspath(os.path.expanduser(path))
    if os.path.exists(path):
        return path
    if data.startswith('data:'):
        return
    try:
        base64.b64decode(data)
        return
    except Exception:
        pass
    return data


_PARQUET_METADATA_CACHE_SIZE = int(os.getenv('SWIFT_PARQUET_METADATA_CACHE_SIZE', '64'))
_PARQUET_ROW_GROUP_CACHE_SIZE = int(os.getenv('SWIFT_PARQUET_ROWGROUP_CACHE_SIZE', '16'))

_PARQUET_ERROR_LOCK = threading.Lock()
_PARQUET_BAD_SHARDS = set()
_PARQUET_BAD_ROW_GROUPS = set()
_PARQUET_BAD_IMAGE_REFS = set()
_PARQUET_ERROR_TYPES = Counter()
_PARQUET_BAD_SHARD_COUNTS = Counter()
_PARQUET_BAD_ROW_GROUP_COUNTS = Counter()
_PARQUET_BAD_IMAGE_REF_COUNTS = Counter()


def _record_parquet_failure(path: str, parquet_path: str, row_group_idx: int | None, exc: Exception) -> None:
    error_key = f'{type(exc).__name__}: {str(exc).strip().splitlines()[0] if str(exc).strip() else type(exc).__name__}'
    with _PARQUET_ERROR_LOCK:
        _PARQUET_ERROR_TYPES[error_key] += 1
        _PARQUET_BAD_SHARD_COUNTS[parquet_path] += 1
        _PARQUET_BAD_IMAGE_REF_COUNTS[path] += 1
        _PARQUET_BAD_IMAGE_REFS.add(path)
        if row_group_idx is None and _is_bad_parquet_shard_error(exc):
            _PARQUET_BAD_SHARDS.add(parquet_path)
        if row_group_idx is not None:
            _PARQUET_BAD_ROW_GROUPS.add((parquet_path, row_group_idx))
            _PARQUET_BAD_ROW_GROUP_COUNTS[f'{parquet_path}@row_group={row_group_idx}'] += 1


def get_parquet_cache_error_stats(reset: bool = False) -> dict:
    with _PARQUET_ERROR_LOCK:
        result = {
            'total_failures': sum(_PARQUET_ERROR_TYPES.values()),
            'error_types': dict(_PARQUET_ERROR_TYPES),
            'bad_shards': _PARQUET_BAD_SHARD_COUNTS.most_common(20),
            'bad_row_groups': _PARQUET_BAD_ROW_GROUP_COUNTS.most_common(20),
            'bad_image_refs': _PARQUET_BAD_IMAGE_REF_COUNTS.most_common(20),
            'known_bad_shard_count': len(_PARQUET_BAD_SHARDS),
            'known_bad_row_group_count': len(_PARQUET_BAD_ROW_GROUPS),
            'known_bad_image_ref_count': len(_PARQUET_BAD_IMAGE_REFS),
        }
        if reset:
            _PARQUET_BAD_SHARDS.clear()
            _PARQUET_BAD_ROW_GROUPS.clear()
            _PARQUET_BAD_IMAGE_REFS.clear()
            _PARQUET_ERROR_TYPES.clear()
            _PARQUET_BAD_SHARD_COUNTS.clear()
            _PARQUET_BAD_ROW_GROUP_COUNTS.clear()
            _PARQUET_BAD_IMAGE_REF_COUNTS.clear()
    return result


def _clear_parquet_caches() -> None:
    _load_parquet_file.cache_clear()
    _load_parquet_row_group_ends.cache_clear()
    _detect_parquet_image_column.cache_clear()
    _load_parquet_image_row_group.cache_clear()


def _is_retryable_parquet_error(exc: Exception) -> bool:
    message = str(exc)
    retryable_fragments = (
        'Couldn\'t deserialize thrift',
        'Deserializing page header failed',
        'Unexpected end of stream',
        'TProtocolException',
        'Invalid thrift',
    )
    return any(fragment in message for fragment in retryable_fragments)


def _is_bad_parquet_shard_error(exc: Exception) -> bool:
    message = str(exc)
    bad_shard_fragments = (
        'Parquet magic bytes not found',
        'is not a parquet file',
        'No such file or directory',
        'Could not open Parquet input source',
        'Failed to open local file',
    )
    return any(fragment in message for fragment in bad_shard_fragments)


def _raise_if_known_bad_shard(parquet_path: str) -> None:
    if parquet_path in _PARQUET_BAD_SHARDS:
        raise OSError(f'Known bad parquet shard: {parquet_path}')


@lru_cache(maxsize=_PARQUET_METADATA_CACHE_SIZE)
def _load_parquet_file(parquet_path: str):
    import pyarrow.parquet as pq
    _raise_if_known_bad_shard(parquet_path)
    return pq.ParquetFile(parquet_path)


@lru_cache(maxsize=_PARQUET_METADATA_CACHE_SIZE)
def _load_parquet_row_group_ends(parquet_path: str):
    parquet_file = _load_parquet_file(parquet_path)
    row_group_ends = []
    total = 0
    for row_group_idx in range(parquet_file.num_row_groups):
        total += parquet_file.metadata.row_group(row_group_idx).num_rows
        row_group_ends.append(total)
    return tuple(row_group_ends)


@lru_cache(maxsize=_PARQUET_METADATA_CACHE_SIZE)
def _detect_parquet_image_column(parquet_path: str) -> str:
    parquet_file = _load_parquet_file(parquet_path)
    names = set(parquet_file.schema_arrow.names)
    for candidate in ('image', 'images'):
        if candidate in names:
            return candidate
    raise KeyError(f'No supported image column found in parquet schema: {parquet_file.schema_arrow.names}')


@lru_cache(maxsize=_PARQUET_ROW_GROUP_CACHE_SIZE)
def _load_parquet_image_row_group(parquet_path: str, row_group_idx: int):
    parquet_file = _load_parquet_file(parquet_path)
    image_column = _detect_parquet_image_column(parquet_path)
    table = parquet_file.read_row_group(row_group_idx, columns=[image_column])
    return tuple(table.column(image_column).to_pylist())


def _parse_parquet_image_ref(path: str):
    if '@' not in path or '.parquet@' not in path:
        return None
    parquet_path, query = path.split('@', 1)
    params = parse_qs(query, keep_blank_values=True)
    row_idx = params.get('row_idx')
    img_idx = params.get('img_idx')
    if not row_idx or not img_idx:
        return None
    try:
        return parquet_path, int(row_idx[0]), int(img_idx[0])
    except ValueError:
        return None


def _locate_parquet_row_group(parquet_path: str, row_idx: int):
    row_group_ends = _load_parquet_row_group_ends(parquet_path)
    row_group_idx = bisect.bisect_right(row_group_ends, row_idx)
    if row_group_idx >= len(row_group_ends):
        raise IndexError(f'row_idx={row_idx} out of range for parquet: {parquet_path}')
    row_group_start = 0 if row_group_idx == 0 else row_group_ends[row_group_idx - 1]
    return row_group_idx, row_group_start


def _resolve_parquet_row(parquet_path: str, row_idx: int):
    _raise_if_known_bad_shard(parquet_path)
    row_group_idx, row_group_start = _locate_parquet_row_group(parquet_path, row_idx)
    if (parquet_path, row_group_idx) in _PARQUET_BAD_ROW_GROUPS:
        raise OSError(f'Known bad parquet row group: {parquet_path}@row_group={row_group_idx}')
    row_group_rows = _load_parquet_image_row_group(parquet_path, row_group_idx)
    return row_group_rows[row_idx - row_group_start]


def _extract_parquet_image_item(image_item: Any, img_idx: int, path: str) -> bytes:
    if isinstance(image_item, tuple):
        image_item = list(image_item)
    if isinstance(image_item, list):
        image_item = image_item[img_idx]
    elif img_idx != 0:
        raise IndexError(f'img_idx={img_idx} out of range for single-image row: {path}')
    if isinstance(image_item, dict):
        image_item = image_item.get('bytes') or image_item.get('path')
    if isinstance(image_item, memoryview):
        image_item = image_item.tobytes()
    if isinstance(image_item, str):
        loaded = load_file(image_item)
        return loaded.getvalue() if isinstance(loaded, BytesIO) else loaded
    if not isinstance(image_item, (bytes, bytearray)):
        raise TypeError(f'Unsupported parquet image payload type: {type(image_item)} for {path}')
    return bytes(image_item)


def _load_parquet_image_bytes(path: str) -> bytes:
    parsed = _parse_parquet_image_ref(path)
    if parsed is None:
        raise ValueError(f'Invalid parquet image ref: {path}')
    parquet_path, row_idx, img_idx = parsed
    row_group_idx = None
    try:
        row_group_idx, _ = _locate_parquet_row_group(parquet_path, row_idx)
        image_item = _resolve_parquet_row(parquet_path, row_idx)
        return _extract_parquet_image_item(image_item, img_idx, path)
    except Exception as e:
        if _is_retryable_parquet_error(e):
            try:
                _clear_parquet_caches()
                row_group_idx, _ = _locate_parquet_row_group(parquet_path, row_idx)
                image_item = _resolve_parquet_row(parquet_path, row_idx)
                return _extract_parquet_image_item(image_item, img_idx, path)
            except Exception as retry_e:
                e = retry_e
        _record_parquet_failure(path, parquet_path, row_group_idx, e)
        raise


_TAR_FD_CACHE_SIZE = get_env_args('SWIFT_TAR_FD_CACHE_SIZE', int, 128)
_TAR_FD_CACHE = OrderedDict()
_TAR_FD_CACHE_LOCK = threading.Lock()


def _parse_tar_image_ref(path: str):
    if '@' not in path or '.tar@' not in path:
        return None
    tar_path, query = path.split('@', 1)
    params = parse_qs(query, keep_blank_values=True)
    offset = params.get('offset')
    size = params.get('size')
    if not offset or not size:
        return None
    member = params.get('member', [None])[0]
    try:
        return tar_path, int(offset[0]), int(size[0]), member
    except ValueError:
        return None


def _open_tar_fd(tar_path: str) -> int:
    fd = _TAR_FD_CACHE.pop(tar_path, None)
    if fd is None:
        fd = os.open(tar_path, os.O_RDONLY)
    _TAR_FD_CACHE[tar_path] = fd
    while len(_TAR_FD_CACHE) > _TAR_FD_CACHE_SIZE:
        _, stale_fd = _TAR_FD_CACHE.popitem(last=False)
        try:
            os.close(stale_fd)
        except OSError:
            pass
    return fd


def _load_tar_image_bytes(path: str) -> bytes:
    parsed = _parse_tar_image_ref(path)
    if parsed is None:
        raise ValueError(f'Invalid tar image ref: {path}')
    tar_path, offset, size, member = parsed
    if _TAR_FD_CACHE_SIZE > 0:
        # Keep the read inside the lock so another thread cannot evict this fd mid-pread.
        with _TAR_FD_CACHE_LOCK:
            data = os.pread(_open_tar_fd(tar_path), size, offset)
    else:
        fd = os.open(tar_path, os.O_RDONLY)
        try:
            data = os.pread(fd, size, offset)
        finally:
            os.close(fd)
    if len(data) != size:
        detail = f'tar={tar_path}, offset={offset}, size={size}'
        if member:
            detail += f', member={member}'
        raise EOFError(f'Short read for tar image ref: {detail}, got={len(data)}')
    return data


def load_file(path: Union[str, bytes, _T]) -> Union[BytesIO, _T]:
    res = path
    if isinstance(path, str):
        path = path.strip()
        parquet_ref = _parse_parquet_image_ref(path)
        if parquet_ref is not None:
            res = BytesIO(_load_parquet_image_bytes(path))
        tar_ref = None if parquet_ref is not None else _parse_tar_image_ref(path)
        if tar_ref is not None:
            res = BytesIO(_load_tar_image_bytes(path))
        # Resolve local archive references before ordinary paths and URLs.
        if parquet_ref is not None or tar_ref is not None:
            pass
        elif path.startswith('http'):
            retries = Retry(total=3, backoff_factor=1, allowed_methods=['GET'])
            with requests.Session() as session:
                session.mount('http://', HTTPAdapter(max_retries=retries))
                session.mount('https://', HTTPAdapter(max_retries=retries))
                timeout = float(os.getenv('SWIFT_TIMEOUT', '20'))
                request_kwargs = {'timeout': timeout} if timeout > 0 else {}

                response = session.get(path, **request_kwargs)
                response.raise_for_status()
                content = response.content
                res = BytesIO(content)
        else:
            data = path
            path = _check_path(path)
            if path is None:
                # base64_str
                if data.startswith('data:'):
                    match_ = re.match(r'data:(.+?);base64,(.+)', data)
                    assert match_ is not None
                    data = match_.group(2)
                data = base64.b64decode(data)
                res = BytesIO(data)
            else:
                with open(path, 'rb') as f:
                    res = BytesIO(f.read())
    elif isinstance(path, bytes):
        res = BytesIO(path)
    return res


def load_image(image: Union[str, bytes, Image.Image]) -> Image.Image:
    image = load_file(image)
    if isinstance(image, BytesIO):
        image = Image.open(image)
    if image.mode != 'RGB':
        image = image.convert('RGB')
    return image


def load_batch(path_list: List[Union[str, None, Any, BytesIO]],
               load_func: Callable[[Any], _T] = load_image) -> List[_T]:
    res = []
    assert isinstance(path_list, (list, tuple)), f'path_list: {path_list}'
    for path in path_list:
        if path is None:  # ignore None
            continue
        res.append(load_func(path))
    return res


def load_video_hf(videos: List[str]):
    from transformers.video_utils import load_video
    res = []
    video_metadata = []
    for video in videos:
        if isinstance(video, (list, tuple)) and isinstance(video[0], str):
            # Case a: Video is provided as a list of image file names
            video = [np.array(load_image(image_fname)) for image_fname in video]
            video = np.stack(video)
            metadata = None
        else:
            # Case b: Video is provided as a single file path or URL or decoded frames in a np.ndarray or torch.tensor
            video_load_backend = get_env_args('video_load_backend', str, 'pyav')
            video, metadata = load_video(
                video,
                backend=video_load_backend,
            )
        res.append(video)
        video_metadata.append(metadata)
    return res, video_metadata


def _get_index(bound, fps, max_frame, first_idx=0, num_segments=32):
    if bound:
        start, end = bound[0], bound[1]
    else:
        start, end = -100000, 100000
    start_idx = max(first_idx, round(start * fps))
    end_idx = min(round(end * fps), max_frame)
    seg_size = float(end_idx - start_idx) / num_segments
    frame_indices = np.array(
        [int(start_idx + (seg_size / 2) + np.round(seg_size * idx)) for idx in range(num_segments)])
    return frame_indices


def transform_image(image, input_size=448, max_num=12):
    transform = _build_transform(input_size=input_size)
    images = _dynamic_preprocess(image, image_size=input_size, use_thumbnail=True, max_num=max_num)
    pixel_values = [transform(image) for image in images]
    pixel_values = torch.stack(pixel_values)
    return pixel_values


def load_video_internvl(video: Union[str, bytes], bound=None, num_segments=32):
    from decord import VideoReader, cpu
    video_io = load_file(video)
    vr = VideoReader(video_io, ctx=cpu(0), num_threads=1)
    max_frame = len(vr) - 1
    fps = float(vr.get_avg_fps())

    images = []
    frame_indices = _get_index(bound, fps, max_frame, first_idx=0, num_segments=num_segments)
    for frame_index in frame_indices:
        images.append(Image.fromarray(vr[frame_index].asnumpy()).convert('RGB'))
    return images


def load_video_cogvlm2(video: Union[str, bytes]) -> np.ndarray:
    from decord import VideoReader, bridge, cpu
    video_io = load_file(video)
    bridge.set_bridge('torch')
    clip_end_sec = 60
    clip_start_sec = 0
    num_frames = get_env_args('num_frames', int, 24)
    decord_vr = VideoReader(video_io, ctx=cpu(0))
    duration = len(decord_vr)  # duration in terms of frames
    start_frame = int(clip_start_sec * decord_vr.get_avg_fps())
    end_frame = min(duration, int(clip_end_sec * decord_vr.get_avg_fps())) if \
        clip_end_sec is not None else duration
    frame_id_list = np.linspace(start_frame, end_frame - 1, num_frames, dtype=int)
    video_data = decord_vr.get_batch(frame_id_list)
    video_data = video_data.permute(3, 0, 1, 2)
    return video_data


def load_video_llava(video: Union[str, bytes]) -> np.ndarray:
    import av
    video_io = load_file(video)
    container = av.open(video_io)
    total_frames = container.streams.video[0].frames
    num_frames = get_env_args('num_frames', int, 16)
    indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
    frames = []
    container.seek(0)
    start_index = indices[0]
    end_index = indices[-1]
    for i, frame in enumerate(container.decode(video=0)):
        if i > end_index:
            break
        if i >= start_index and i in indices:
            frames.append(frame)
    return np.stack([x.to_ndarray(format='rgb24') for x in frames])


def load_video_minicpmv_mplug_owl3(video: Union[str, bytes], max_num_frames):

    from decord import VideoReader, cpu  # pip install decord

    def uniform_sample(_l, _n):
        gap = len(_l) / _n
        idxs = [int(i * gap + gap / 2) for i in range(_n)]
        return [_l[i] for i in idxs]

    video_io = load_file(video)
    vr = VideoReader(video_io, ctx=cpu(0))
    sample_fps = round(vr.get_avg_fps() / 1)  # FPS
    frame_idx = [i for i in range(0, len(vr), sample_fps)]

    if len(frame_idx) > max_num_frames:
        frame_idx = uniform_sample(frame_idx, max_num_frames)
    frames = vr.get_batch(frame_idx).asnumpy()
    frames = [Image.fromarray(v.astype('uint8')) for v in frames]
    return frames


def load_audio(audio: Union[str, bytes], sampling_rate: int, return_sr: bool = False):
    import librosa
    audio_io = load_file(audio)
    res = librosa.load(audio_io, sr=sampling_rate)
    return res if return_sr else res[0]


def load_video_valley(video: Union[str, bytes]):
    import decord
    from torchvision import transforms
    video_io = load_file(video)
    video_reader = decord.VideoReader(video_io)
    decord.bridge.set_bridge('torch')
    video = video_reader.get_batch(np.linspace(0, len(video_reader) - 1, 8).astype(np.int_)).byte()
    images = [transforms.ToPILImage()(image.permute(2, 0, 1)).convert('RGB') for image in video]
    return images


def load_video_ovis2(video_path, num_frames):
    from moviepy.editor import VideoFileClip
    with VideoFileClip(video_path) as clip:
        total_frames = int(clip.fps * clip.duration)
        if total_frames <= num_frames:
            sampled_indices = range(total_frames)
        else:
            stride = total_frames / num_frames
            sampled_indices = [
                min(total_frames - 1, int((stride * i + stride * (i + 1)) / 2)) for i in range(num_frames)
            ]
        frames = [clip.get_frame(index / clip.fps) for index in sampled_indices]
        frames = [Image.fromarray(frame, mode='RGB') for frame in frames]
    return frames


def load_video_ovis2_5(video_path, num_frames):
    from moviepy.editor import VideoFileClip
    with VideoFileClip(video_path) as clip:
        total_frames = int(clip.fps * clip.duration)
        indices = [int(i * total_frames / num_frames) for i in range(num_frames)]
        frames = [Image.fromarray(clip.get_frame(t)) for t in (idx / clip.fps for idx in indices)]
    return frames
