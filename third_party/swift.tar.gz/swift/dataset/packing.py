# Copyright (c) ModelScope Contributors. All rights reserved.
import gc
import hashlib
import json
import math
import multiprocessing as mp
import os
import tempfile
import time
import torch.distributed as dist
import numpy as np
from pathlib import Path
from torch.utils.data import Dataset, IterableDataset
from tqdm import tqdm
from typing import Optional

from swift.dataset.utils import LazyLLMDataset, data_profile_log
from swift.template import MaxLengthError
from swift.utils import get_logger, is_dist, is_master, split_list

logger = get_logger()


class _PackedIndexView:
    """List-like view backed by CSR-style mmap arrays."""

    def __init__(self, dataset: 'PackingDataset'):
        self.dataset = dataset

    def __len__(self):
        return self.dataset._packed_groups

    def __bool__(self):
        return len(self) > 0

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(len(self)))]
        return self.dataset._get_packed_sequence(index)


def calculate_matched_group(sequences, packing_length: int, is_finished: bool = True):
    if len(sequences) == 0:
        return [], []
    # https://arxiv.org/pdf/2404.10830
    import binpacking
    sequences = binpacking.to_constant_volume(sequences, packing_length, weight_pos=1)
    if sequences and not is_finished:
        sequences, ret_sequences = sequences[:-1], sequences[-1]
    else:
        ret_sequences = []
    return sequences, ret_sequences


class PackingDataset(Dataset):
    PACKING_BATCH_SIZE = 1000

    def __init__(
        self,
        template,
        dataset,
        num_proc: int = 1,
        *,
        strict: bool = False,
        load_from_cache_file: bool = True,
        packing_length: Optional[int] = None,
        packing_num_proc: int = 1,
        **kwargs,
    ):
        import time as _time

        t_total = _time.monotonic()
        template.packing = True
        template.padding_free = True  # TODO: remove
        self.template = template
        self.dataset = dataset
        self.num_proc = num_proc
        self.strict = strict
        self.load_from_cache_file = load_from_cache_file
        self.packing_length = packing_length or self.template.max_length
        self.packing_num_proc = min(packing_num_proc, math.ceil(len(dataset) / self.PACKING_BATCH_SIZE))
        self._out_queue = mp.Queue()
        self._packing_memmap_meta_path = None
        self._packed_offsets = None
        self._packed_indices = None
        self._packed_groups = 0
        self.packed_idx = None
        self.packed_length = None
        self._packing_init_wall_time = time.time()
        self._packing_max_actual_length = self._get_env_int(
            'SWIFT_PACKING_MAX_ACTUAL_LENGTH', self.packing_length)
        self._packing_keep_overlength_singletons = bool(self._get_env_int(
            'SWIFT_PACKING_KEEP_OVERLENGTH_SINGLETONS', 0))
        self._packing_cached_length_scale = self._get_env_float(
            'SWIFT_PACKING_CACHED_LENGTH_SCALE', 1.0)
        if self._packing_cached_length_scale < 1.0:
            raise ValueError('SWIFT_PACKING_CACHED_LENGTH_SCALE must be >= 1.0')
        self._packing_max_skip_tries = self._get_env_int(
            'SWIFT_PACKING_MAX_SKIP_TRIES', 128)
        self._packing_skip_groups = self._parse_int_set(os.environ.get('SWIFT_PACKING_SKIP_GROUPS', ''))
        self._packing_actual_skip_count = 0
        _num_rows = len(dataset)
        memmap_dir = self._get_packing_memmap_dir(_num_rows)
        meta_path = memmap_dir / 'meta.json'
        done_path = memmap_dir / 'DONE'
        self._packing_memmap_meta_path = str(meta_path)
        if done_path.exists() and meta_path.exists():
            try:
                with open(meta_path) as f:
                    cached_meta = json.load(f)
                meta_matches = (
                    int(cached_meta.get('num_rows', -1)) == int(_num_rows)
                    and int(cached_meta.get('packing_length', -1)) == int(self.packing_length)
                    and int(cached_meta.get('packing_num_proc', -1)) == int(self.packing_num_proc)
                    and bool(cached_meta.get('keep_overlength_singletons', False))
                    == self._packing_keep_overlength_singletons
                    and float(cached_meta.get('cached_length_scale', 1.0))
                    == self._packing_cached_length_scale
                )
                if meta_matches:
                    self._load_packing_memmap(meta_path)
                    logger.info(f'PackingDataset: reused cached mmap index from {memmap_dir} ')
                    if dist.is_initialized() and is_dist():
                        logger.info(f'PackingDataset: mmap index ready without object broadcast (packed_groups={len(self)})')
                        data_profile_log(f'PackingDataset mmap_ready packed_groups={len(self)}')
                    return
                logger.warning(
                    f'PackingDataset: cached mmap metadata mismatch at {meta_path}; rebuilding. '
                    f'expected rows={_num_rows}, packing_length={self.packing_length}, '
                    f'packing_num_proc={self.packing_num_proc}, got {cached_meta}')
            except Exception as e:
                logger.warning(f'PackingDataset: failed to load cached mmap index at {meta_path}: {e}; rebuilding.')
            if is_master() and done_path.exists():
                done_path.unlink()
        if is_master():
            logger.info(f'PackingDataset: loading length column for {_num_rows} rows (this may take a while)...')
            _t_len_start = _time.monotonic()
            gc.disable()
            try:
                lengths = self._load_length_column(dataset)
            finally:
                gc.enable()
            _t_len_elapsed = _time.monotonic() - _t_len_start
            logger.info(f'PackingDataset: length column loaded in {_t_len_elapsed:.1f}s, '
                        f'starting packing workers...')
            gc.disable()
            _t_pack_start = _time.monotonic()
            try:
                offset = 0
                chunked_lengths = split_list(lengths, self.packing_num_proc)
                for i in range(self.packing_num_proc):
                    worker = mp.Process(
                        target=self.create_packed_idx, args=(
                            i,
                            offset,
                            chunked_lengths[i],
                        ), daemon=True)
                    worker.start()
                    offset += len(chunked_lengths[i])
                packed_idx_parts = [[] for _ in range(self.packing_num_proc)]
                packed_length_parts = [[] for _ in range(self.packing_num_proc)]
                desc = 'Packing: ' if self.packing_num_proc == 1 else f'Packing (num_proc={self.packing_num_proc}): '
                dropped_overlength = 0
                retained_overlength = 0
                with tqdm(total=len(lengths), dynamic_ncols=True, desc=desc) as prog_bar:
                    finished_workers = 0
                    while finished_workers < self.packing_num_proc:
                        msg = self._out_queue.get()
                        if len(msg) == 5:
                            rank, sequences, data_len, dropped, retained = msg
                        elif len(msg) == 4:
                            rank, sequences, data_len, dropped = msg
                            retained = 0
                        else:
                            rank, sequences, data_len = msg
                            dropped = 0
                            retained = 0
                        dropped_overlength += dropped
                        retained_overlength += retained
                        if data_len == -1:
                            finished_workers += 1
                            continue
                        prog_bar.update(data_len)
                        packed_idx_parts[rank] += [[x[0] for x in seq] for seq in sequences]
                        packed_length_parts[rank] += [sum(x[1] for x in seq) for seq in sequences]
                if dropped_overlength:
                    logger.warning(
                        f'PackingDataset: dropped {dropped_overlength} overlength rows '
                        f'(length > packing_length={self.packing_length}) before packing.')
                if retained_overlength:
                    logger.info(
                        f'PackingDataset: retained {retained_overlength} rows with cached length above '
                        f'packing_length={self.packing_length} as singleton groups; '
                        f'actual max length remains {self._packing_max_actual_length}.')
                self._dump_packing_memmap(
                    memmap_dir,
                    meta_path,
                    done_path,
                    packed_idx_parts,
                    packed_length_parts,
                    num_rows=_num_rows,
                    t_total=t_total,
                )
                del packed_idx_parts, packed_length_parts, lengths, chunked_lengths
            finally:
                gc.enable()
                gc.collect()
            _t_pack_elapsed = _time.monotonic() - _t_pack_start
            self._load_packing_memmap(meta_path)
            packed_groups = len(self)
            avg_packed_length = float(self.packed_length.mean()) if packed_groups else 0
            compression = (_num_rows / packed_groups) if packed_groups else 0
            data_profile_log(
                f'PackingDataset build length_load={_t_len_elapsed:.3f}s packing={_t_pack_elapsed:.3f}s '
                f'total={_time.monotonic() - t_total:.3f}s rows={_num_rows} packed_groups={packed_groups} '
                f'avg_packed_length={avg_packed_length:.1f} compression={compression:.2f} '
                f'packing_num_proc={self.packing_num_proc}')
        else:
            self._wait_and_load_packing_memmap(meta_path, done_path)
        if dist.is_initialized() and is_dist():
            logger.info(f'PackingDataset: mmap index ready without object broadcast (packed_groups={len(self)})')
            data_profile_log(f'PackingDataset mmap_ready packed_groups={len(self)}')

    def _get_packing_memmap_dir(self, num_rows: int) -> Path:
        cache_root = os.environ.get('SWIFT_PACKING_MEMMAP_DIR')
        if not cache_root:
            cache_root = os.path.join(tempfile.gettempdir(), 'swift_packing_memmap')
        cache_root = Path(cache_root)
        cache_root.mkdir(parents=True, exist_ok=True)
        key_src = '|'.join([
            'v3',
            str(num_rows),
            str(self.packing_length),
            str(self.packing_num_proc),
            str(int(self._packing_keep_overlength_singletons)),
            format(self._packing_cached_length_scale, '.8g'),
        ])
        key = hashlib.sha1(key_src.encode()).hexdigest()[:16]
        memmap_dir = cache_root / key
        memmap_dir.mkdir(parents=True, exist_ok=True)
        return memmap_dir

    def _dump_packing_memmap(self, memmap_dir: Path, meta_path: Path, done_path: Path, packed_idx_parts,
                             packed_length_parts, *, num_rows: int, t_total: float) -> None:
        if done_path.exists():
            done_path.unlink()

        packed_groups = sum(len(part) for part in packed_idx_parts)
        flat_indices = sum(len(seq) for part in packed_idx_parts for seq in part)
        index_dtype = np.uint32 if num_rows <= np.iinfo(np.uint32).max else np.int64
        length_dtype = np.uint32 if self.packing_length <= np.iinfo(np.uint32).max else np.uint64

        offsets_path = memmap_dir / 'packed_offsets.npy'
        indices_path = memmap_dir / 'packed_indices.npy'
        lengths_path = memmap_dir / 'packed_length.npy'

        logger.info(
            f'PackingDataset: writing mmap index to {memmap_dir} '
            f'(packed_groups={packed_groups}, flat_indices={flat_indices}, index_dtype={np.dtype(index_dtype).name})')

        offsets = np.lib.format.open_memmap(offsets_path, mode='w+', dtype=np.uint64, shape=(packed_groups + 1,))
        indices = np.lib.format.open_memmap(indices_path, mode='w+', dtype=index_dtype, shape=(flat_indices,))
        lengths = np.lib.format.open_memmap(lengths_path, mode='w+', dtype=length_dtype, shape=(packed_groups,))

        offset_pos = 0
        group_idx = 0
        offsets[0] = 0
        for part_idx, (idx_part, length_part) in enumerate(zip(packed_idx_parts, packed_length_parts)):
            if len(idx_part) != len(length_part):
                raise ValueError(f'PackingDataset worker {part_idx} returned mismatched idx/length sizes: '
                                 f'{len(idx_part)} vs {len(length_part)}')
            for seq, seq_length in zip(idx_part, length_part):
                next_pos = offset_pos + len(seq)
                indices[offset_pos:next_pos] = seq
                offset_pos = next_pos
                group_idx += 1
                offsets[group_idx] = offset_pos
                lengths[group_idx - 1] = seq_length

        offsets.flush()
        indices.flush()
        lengths.flush()

        meta = {
            'version': 1,
            'num_rows': int(num_rows),
            'packing_length': int(self.packing_length),
            'packing_num_proc': int(self.packing_num_proc),
            'keep_overlength_singletons': bool(self._packing_keep_overlength_singletons),
            'cached_length_scale': float(self._packing_cached_length_scale),
            'packed_groups': int(packed_groups),
            'flat_indices': int(flat_indices),
            'offsets_path': str(offsets_path),
            'indices_path': str(indices_path),
            'lengths_path': str(lengths_path),
            'index_dtype': np.dtype(index_dtype).name,
            'length_dtype': np.dtype(length_dtype).name,
            'created_at': time.time(),
            'elapsed': time.monotonic() - t_total,
        }
        tmp_meta_path = meta_path.with_suffix('.json.tmp')
        with open(tmp_meta_path, 'w') as f:
            json.dump(meta, f, indent=2, sort_keys=True)
        os.replace(tmp_meta_path, meta_path)
        done_path.write_text('ok\n')

    def _wait_and_load_packing_memmap(self, meta_path: Path, done_path: Path) -> None:
        timeout = float(os.environ.get('SWIFT_PACKING_MEMMAP_TIMEOUT', 7200))
        start = time.monotonic()
        while True:
            if done_path.exists() and meta_path.exists():
                break
            if time.monotonic() - start > timeout:
                raise TimeoutError(f'Timed out waiting for packing mmap metadata: {done_path}')
            time.sleep(2)
        self._load_packing_memmap(meta_path)

    def _load_packing_memmap(self, meta_path: Path) -> None:
        with open(meta_path) as f:
            meta = json.load(f)
        self._packing_memmap_meta_path = str(meta_path)
        self._packed_offsets = np.load(meta['offsets_path'], mmap_mode='r')
        self._packed_indices = np.load(meta['indices_path'], mmap_mode='r')
        self.packed_length = np.load(meta['lengths_path'], mmap_mode='r')
        self._packed_groups = int(meta['packed_groups'])
        self.packed_idx = _PackedIndexView(self)
        logger.info(
            f'PackingDataset: mmap index loaded from {Path(meta_path).parent} '
            f'(packed_groups={self._packed_groups}, flat_indices={int(meta["flat_indices"])})')

    def _get_packed_sequence(self, index):
        index = int(index)
        if index < 0:
            index += self._packed_groups
        if index < 0 or index >= self._packed_groups:
            raise IndexError(index)
        start = int(self._packed_offsets[index])
        end = int(self._packed_offsets[index + 1])
        return [int(i) for i in self._packed_indices[start:end]]

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_out_queue'] = None
        state['_packed_offsets'] = None
        state['_packed_indices'] = None
        state['packed_idx'] = None
        state['packed_length'] = None
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        if self._packing_memmap_meta_path:
            self._load_packing_memmap(Path(self._packing_memmap_meta_path))

    @staticmethod
    def _load_length_column(dataset):
        """Load length column via Arrow fast path when possible."""
        import time as _time

        inner = dataset.dataset if isinstance(dataset, LazyLLMDataset) else dataset
        primary = 'length'
        fallback = 'lengths'

        if hasattr(inner, '_data') and inner._data is not None:
            import pyarrow as pa

            t0 = _time.monotonic()
            try:
                col = inner._data.column(primary)
            except Exception:
                col = inner._data.column(fallback)
            t_access = _time.monotonic() - t0

            arrow_len = len(col)
            actual_len = len(inner)

            if arrow_len != actual_len:
                logger.warning(
                    f'  [length-diag] Arrow raw rows ({arrow_len}) != dataset rows ({actual_len}), '
                    f'unmaterialized select() indices detected.')
                t_safe = _time.monotonic()
                indices_table = getattr(inner, '_indices', None)
                if indices_table is not None:
                    indices_col = indices_table.column(0)
                    t_seq = _time.monotonic()
                    if col.num_chunks > 1:
                        raw_arr = col.combine_chunks()
                    else:
                        raw_arr = col.chunk(0)
                    is_numeric = pa.types.is_integer(raw_arr.type) or pa.types.is_floating(raw_arr.type)
                    if is_numeric:
                        raw_lengths = raw_arr.to_numpy(zero_copy_only=False)
                    else:
                        raw_lengths = np.asarray(raw_arr.to_pylist(), dtype=object)

                    if indices_col.num_chunks > 1:
                        idx_arr = indices_col.combine_chunks()
                    else:
                        idx_arr = indices_col.chunk(0)
                    indices = idx_arr.to_numpy(zero_copy_only=False).astype(np.int64, copy=False)
                    lengths = raw_lengths[indices]
                    logger.info(
                        f'  [length-diag] numpy indexed length load completed in {_time.monotonic() - t_seq:.2f}s '
                        f'(raw={len(raw_lengths)}, indices={len(indices)}, result={len(lengths)})')
                else:
                    cols = getattr(inner, 'column_names', None) or []
                    lengths = inner[primary] if primary in cols else inner[fallback]
                    logger.info(
                        f'  [length-diag] Safe accessor fallback completed in '
                        f'{_time.monotonic() - t_safe:.2f}s')
                return lengths

            is_numeric = pa.types.is_integer(col.type) or pa.types.is_floating(col.type)
            logger.info(
                f'  [length-diag] Arrow col: chunks={col.num_chunks}, type={col.type}, '
                f'nbytes={col.nbytes / 1e9:.2f}GB, col_lookup={t_access:.2f}s')

            t1 = _time.monotonic()
            if col.num_chunks > 1:
                arr = col.combine_chunks()
            else:
                arr = col.chunk(0)
            t_io = _time.monotonic() - t1

            t2 = _time.monotonic()
            if is_numeric:
                lengths = arr.to_numpy(zero_copy_only=False)
            else:
                lengths = arr.to_pylist()
            t_conv = _time.monotonic() - t2

            fmt = 'numpy' if is_numeric else 'pylist'
            logger.info(
                f'  [length-diag] combine_chunks(IO)={t_io:.2f}s, '
                f'to_{fmt}(convert)={t_conv:.2f}s, '
                f'total={t_access + t_io + t_conv:.2f}s')
            return lengths

        t0 = _time.monotonic()
        try:
            lengths = dataset[primary]
        except Exception:
            lengths = dataset[fallback]
        logger.info(f'  [length-diag] HfDataset fallback: {_time.monotonic() - t0:.2f}s')
        return lengths

    def create_packed_idx(self, rank, offset, lengths):
        gc.disable()
        try:
            raw_data = []
            for i, length in enumerate(lengths):
                cached_length = sum(length) if isinstance(length, list) else length
                scaled_length = int(math.ceil(float(cached_length) * self._packing_cached_length_scale))
                raw_data.append((i + offset, int(cached_length), scaled_length))
            i = 0
            input_data = []
            dropped_overlength = 0
            retained_overlength = 0
            while True:
                raw_new_data = raw_data[i:i + self.PACKING_BATCH_SIZE]
                new_data = []
                singleton_sequences = []
                for sample_idx, cached_length, sample_length in raw_new_data:
                    if sample_length > self.packing_length:
                        if (self._packing_keep_overlength_singletons
                                and cached_length <= self._packing_max_actual_length):
                            singleton_sequences.append([(sample_idx, sample_length)])
                            retained_overlength += 1
                        else:
                            dropped_overlength += 1
                        continue
                    new_data.append((sample_idx, sample_length))
                input_data += new_data
                i += self.PACKING_BATCH_SIZE
                is_finished = i >= len(raw_data)
                if not input_data and is_finished:
                    if singleton_sequences:
                        self._out_queue.put((rank, singleton_sequences, len(raw_new_data), 0, 0))
                    break
                if not input_data:
                    self._out_queue.put((rank, singleton_sequences, len(raw_new_data), 0, 0))
                    continue
                sequences, input_data = calculate_matched_group(input_data, self.packing_length, is_finished=is_finished)
                sequences += singleton_sequences
                self._out_queue.put((rank, sequences, len(raw_new_data), 0, 0))
            self._out_queue.put((rank, [], -1, dropped_overlength, retained_overlength))
        finally:
            gc.enable()

    @staticmethod
    def _get_env_int(name: str, default: int) -> int:
        value = os.environ.get(name)
        if value is None or value == '':
            return int(default)
        return int(value)

    @staticmethod
    def _get_env_float(name: str, default: float) -> float:
        value = os.environ.get(name)
        if value is None or value == '':
            return float(default)
        return float(value)

    @staticmethod
    def _parse_int_set(value: str):
        ret = set()
        for item in value.replace(';', ',').split(','):
            item = item.strip()
            if not item:
                continue
            ret.add(int(item))
        return ret

    @staticmethod
    def _row_actual_length(row) -> int:
        if not isinstance(row, dict):
            return 0
        length = row.get('length', row.get('lengths'))
        if length is not None:
            if isinstance(length, (list, tuple, np.ndarray)):
                return int(sum(length))
            try:
                return int(length)
            except TypeError:
                return int(np.asarray(length).sum())
        lengths = []
        for key in ('input_ids', 'labels'):
            value = row.get(key)
            if value is not None:
                lengths.append(len(value))
        return max(lengths) if lengths else 0

    def _log_skip_group(self, index: int, sequence, actual_lengths, cached_length, reason: str) -> None:
        self._packing_actual_skip_count += 1
        if self._packing_actual_skip_count <= 16 or self._packing_actual_skip_count % 100 == 0:
            logger.warning(
                'PackingDataset: skip packed group before training forward '
                f'(reason={reason}, group={int(index)}, rows={len(sequence)}, '
                f'cached_length={int(cached_length) if cached_length is not None else None}, '
                f'actual_length={sum(actual_lengths)}, actual_lengths={actual_lengths[:16]}, '
                f'sequence={list(sequence)[:16]}, skip_count={self._packing_actual_skip_count})')

    def __getitem__(self, index):
        start_index = int(index)
        fallback_row = None
        fallback_meta = None
        max_tries = max(1, int(self._packing_max_skip_tries))
        stride = 9973
        for attempt in range(max_tries):
            cur_index = start_index if attempt == 0 else (start_index + attempt * stride) % self._packed_groups
            sequence = self._get_packed_sequence(cur_index)
            if cur_index in self._packing_skip_groups:
                cached_length = self.packed_length[cur_index] if self.packed_length is not None else None
                self._log_skip_group(cur_index, sequence, [], cached_length, 'explicit_skip_group')
                continue
            row = [self.dataset[i] for i in sequence]
            actual_lengths = [self._row_actual_length(r) for r in row]
            actual_length = sum(actual_lengths)
            cached_length = self.packed_length[cur_index] if self.packed_length is not None else None
            if self._packing_max_actual_length > 0 and actual_length > self._packing_max_actual_length:
                self._log_skip_group(cur_index, sequence, actual_lengths, cached_length, 'actual_length')
                if fallback_row is None:
                    selected = []
                    selected_length = 0
                    for row_index in sorted(range(len(row)), key=lambda i: (-actual_lengths[i], i)):
                        row_length = actual_lengths[row_index]
                        if row_length <= 0 or row_length > self._packing_max_actual_length:
                            continue
                        if selected_length + row_length <= self._packing_max_actual_length:
                            selected.append(row_index)
                            selected_length += row_length
                    if selected:
                        selected.sort()
                        fallback_row = [row[i] for i in selected]
                        fallback_meta = (cur_index, len(row), selected_length)
                continue
            return row
        if fallback_row is not None:
            cur_index, original_rows, selected_length = fallback_meta
            logger.warning(
                'PackingDataset: replacement search exhausted; using deterministic safe subset '
                f'(start_group={start_index}, fallback_group={cur_index}, tries={max_tries}, '
                f'rows={len(fallback_row)}/{original_rows}, actual_length={selected_length}, '
                f'max_actual_length={self._packing_max_actual_length})')
            return fallback_row
        raise RuntimeError(
            f'PackingDataset failed to find a safe packed group after {max_tries} tries starting from {start_index}. '
            f'No individual row fit SWIFT_PACKING_MAX_ACTUAL_LENGTH={self._packing_max_actual_length}')

    def __len__(self):
        return self._packed_groups


class IterablePackingDataset(IterableDataset):

    def __init__(
        self,
        template,
        dataset,
        num_proc: int = 1,
        *,
        packing_interval: int = 128,
        packing_length: Optional[int] = None,
        strict: bool = False,
        cyclic: bool = False,
        **kwargs,
    ):
        template.packing = True
        template.padding_free = True  # TODO: remove
        self.template = template
        self.dataset = dataset
        self.num_proc = num_proc
        self.strict = strict
        self.packing_length = packing_length or self.template.max_length

        self.packing_interval = packing_interval
        self._in_queue = mp.Queue()
        self._out_queue = mp.Queue()
        self.workers = []
        self.cyclic = cyclic
        for _ in range(self.num_proc):
            worker = mp.Process(target=self._processor, daemon=True)
            worker.start()
            self.workers.append(worker)

    def _processor(self):
        while True:
            i, data = self._in_queue.get()
            encoded_data = {}
            try:
                encoded_data = self.template.encode(data, return_length=True)
            except Exception as e:
                if self.strict and not isinstance(e, MaxLengthError):
                    raise
            self._out_queue.put((i, encoded_data))

    def _put_data_in_queue(self, iterator) -> int:
        for i in range(self.packing_interval):
            try:
                data = next(iterator)
            except StopIteration:
                return i
            self._in_queue.put((i, data))
        return i + 1

    def _fetch_data_out_queue(self, last_res, num_samples):
        res = [None] * num_samples
        for _ in range(num_samples):
            i, data = self._out_queue.get()
            if not data:
                continue
            res[i] = (data, len(data['input_ids']))
        res = [data for data in res if data]
        last_res += res
        return last_res

    @staticmethod
    def cyclic_iter(iterable):
        while True:
            for x in iterable:
                yield x

    def __iter__(self):
        import time as _time

        try:
            next(iter(self.dataset))
        except StopIteration:
            return

        if self.cyclic:
            iterator = self.cyclic_iter(self.dataset)
        else:
            iterator = iter(self.dataset)
        data = []
        encode_total = 0.0
        queue_in_total = 0.0
        queue_out_total = 0.0
        group_total = 0.0
        yielded_groups = 0
        rounds = 0
        while True:
            t_queue_in = _time.monotonic()
            num_samples = self._put_data_in_queue(iterator)
            queue_in_total += _time.monotonic() - t_queue_in
            finished = num_samples != self.packing_interval
            t_queue_out = _time.monotonic()
            data = self._fetch_data_out_queue(data, num_samples)
            queue_out_total += _time.monotonic() - t_queue_out
            t_group = _time.monotonic()
            sequences, data = calculate_matched_group(data, self.packing_length, is_finished=finished)
            group_total += _time.monotonic() - t_group
            rounds += 1
            res = []
            for row in sequences:
                res.append([r[0] for r in row])
            yielded_groups += len(res)
            if rounds <= 3 or finished:
                data_profile_log(
                    f'IterablePackingDataset round={rounds} num_samples={num_samples} '
                    f'queue_in_total={queue_in_total:.3f}s queue_out_total={queue_out_total:.3f}s '
                    f'group_total={group_total:.3f}s yielded_groups={yielded_groups} pending={len(data)}')
            yield from res
            if finished:
                data_profile_log(
                    f'IterablePackingDataset total rounds={rounds} queue_in_total={queue_in_total:.3f}s '
                    f'queue_out_total={queue_out_total:.3f}s group_total={group_total:.3f}s '
                    f'yielded_groups={yielded_groups} pending={len(data)}')
                break
