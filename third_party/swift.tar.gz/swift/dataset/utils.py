# Copyright (c) ModelScope Contributors. All rights reserved.
import bisect
import inspect
import math
import numpy as np
import os
import tempfile
import time
from datasets import Dataset as HfDataset
from modelscope.hub.utils.utils import get_cache_dir
from torch.utils.data import Dataset
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from swift.template import MaxLengthError, Template
from swift.utils import get_logger
from .preprocessor import RowPreprocessor
from .profile_utils import data_profile_describe_dataset, data_profile_log, is_data_profile_enabled

logger = get_logger()


def _summarize_latency(latencies: List[float]) -> Optional[str]:
    if not latencies:
        return None
    values = np.asarray(latencies, dtype=np.float64)
    p50 = float(np.percentile(values, 50))
    p95 = float(np.percentile(values, 95))
    return (f'calls={len(latencies)}, avg={values.mean() * 1000:.1f}ms, '
            f'p50={p50 * 1000:.1f}ms, p95={p95 * 1000:.1f}ms, max={values.max() * 1000:.1f}ms')


def sample_dataset(
        dataset: HfDataset,
        dataset_sample: Optional[int],
        shuffle: bool = True,
        random_state: Optional[np.random.RandomState] = None,
        shuffle_all: bool = False,  # For compatibility, this defaults to False.
) -> HfDataset:
    """Sample dataset by a dataset_sample number
    Args:
        dataset: The dataset instance, iterable dataset is not supported
        dataset_sample: The sample number
        shuffle: Whether to perform random sampling on non-streaming datasets
        random_state: The random state
    Returns:
        The sampled dataset
    """
    if dataset_sample is None:
        return dataset

    n_repeat_sample = dataset_sample // len(dataset)
    n_remain_sample = dataset_sample % len(dataset)
    if n_repeat_sample >= 1 and n_remain_sample >= 1:
        logger.warning(f'dataset_sample:{dataset_sample} is greater than len(dataset):{len(dataset)}, '
                       'repeated sampling will be performed.')
    idx = np.tile(range(len(dataset)), n_repeat_sample)
    if random_state is None:
        random_state = np.random.RandomState()
    if n_remain_sample >= 1:
        if shuffle:
            # Use choice() instead of permutation()[:k] — O(k) vs O(N) when k << N.
            idx_remain = random_state.choice(len(dataset), size=n_remain_sample, replace=False)
        else:
            idx_remain = np.arange(n_remain_sample)
        idx = np.concatenate([idx, idx_remain])
    if n_repeat_sample >= 1 and shuffle and shuffle_all:
        random_state.shuffle(idx)
    dataset = dataset.select(idx)
    return dataset


class LazyLLMDataset(Dataset):
    """This class if used to lazy tokenize the dataset, and skips bad ones when training"""

    def __init__(self,
                 dataset: HfDataset,
                 encode_func: Callable[[Dict[str, Any]], Dict[str, Any]],
                 *,
                 n_try_fetch: int = 10,
                 strict: bool = False,
                 random_state: Optional[Union[np.random.RandomState, int]] = None,
                 traceback_limit: int = 10) -> None:
        self.dataset = dataset
        self.encode_func = encode_func

        n_try_fetch = 1 if strict else min(n_try_fetch, len(self.dataset))
        assert n_try_fetch >= 1
        self.strict = strict
        self.n_try_fetch = n_try_fetch

        if not isinstance(random_state, np.random.RandomState):
            random_state = np.random.RandomState(random_state)
        self.random_state = random_state

        self.traceback_limit = traceback_limit
        self._traceback_counter = 0
        self._idx = 0
        self._profile_calls = 0
        self._profile_retry_count = 0
        self._profile_max_length_errors = 0
        self._profile_other_errors = 0
        self._profile_latencies: List[float] = []
        self._profile_summary_stride = 128
        _dataset_len = len(self.dataset)
        logger.info(f'LazyLLMDataset: building shuffle index for {_dataset_len} samples...')
        idx_dtype = np.uint32 if _dataset_len <= np.iinfo(np.uint32).max else np.int64
        self._idx_array = np.arange(_dataset_len, dtype=idx_dtype)
        self.random_state.shuffle(self._idx_array)
        self._idx_list = self._idx_array  # Backward-compatible alias; this is not a Python list.
        logger.info(f'LazyLLMDataset: shuffle index built as numpy array dtype={np.dtype(idx_dtype).name}.')

        boundaries: Optional[List[Tuple[int, Optional[str]]]] = getattr(dataset, '_channel_boundaries', None)
        if boundaries and any(ch for _, ch in boundaries):
            self._ch_ends = [b[0] for b in boundaries]
            self._ch_names = [b[1] for b in boundaries]
        else:
            self._ch_ends = None
            self._ch_names = None

    def _lookup_channel(self, row_idx: int) -> Optional[str]:
        if self._ch_ends is None:
            return None
        pos = bisect.bisect_right(self._ch_ends, row_idx)
        if pos < len(self._ch_names):
            return self._ch_names[pos]
        return None

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        if isinstance(idx, str):
            return self.dataset[idx]
        t0 = time.monotonic()
        retries = 0
        for i in range(self.n_try_fetch):
            if i > 0:
                retries += 1
                idx = int(self._idx_array[self._idx])
                self._idx = (self._idx + 1) % len(self.dataset)
            data = self.dataset[idx]
            ch = self._lookup_channel(idx)
            if ch is not None and 'channel' not in data:
                data['channel'] = ch
            try:
                result = self.encode_func(data, return_length=True)
                elapsed = time.monotonic() - t0
                self._profile_calls += 1
                self._profile_retry_count += retries
                self._profile_latencies.append(elapsed)
                if len(self._profile_latencies) > 2048:
                    self._profile_latencies = self._profile_latencies[-1024:]
                if self._profile_calls <= 8 or self._profile_calls % self._profile_summary_stride == 0:
                    summary = _summarize_latency(self._profile_latencies)
                    if summary is not None:
                        data_profile_log(
                            f'LazyLLMDataset __getitem__ {summary}, retries={self._profile_retry_count}, '
                            f'max_length_errors={self._profile_max_length_errors}, '
                            f'other_errors={self._profile_other_errors}')
                return result
            except Exception as e:
                if self.strict:
                    logger.warning('To avoid errors, you can pass `strict=False`.')
                    raise
                if isinstance(e, MaxLengthError):
                    self._profile_max_length_errors += 1
                    continue
                self._profile_other_errors += 1
                if self.traceback_limit is not None and self._traceback_counter < self.traceback_limit:
                    import traceback
                    logger.info(traceback.format_exc())
                    logger.warning('👆👆👆There are errors in the template.encode, '
                                   'and another piece of data will be randomly selected.')
                    self._traceback_counter += 1

        elapsed = time.monotonic() - t0
        self._profile_calls += 1
        self._profile_retry_count += retries
        self._profile_latencies.append(elapsed)
        if len(self._profile_latencies) > 2048:
            self._profile_latencies = self._profile_latencies[-1024:]
        summary = _summarize_latency(self._profile_latencies)
        if summary is not None:
            data_profile_log(
                f'LazyLLMDataset __getitem__ failed {summary}, retries={self._profile_retry_count}, '
                f'max_length_errors={self._profile_max_length_errors}, '
                f'other_errors={self._profile_other_errors}')
        raise ValueError('Failed to retrieve the dataset. You can avoid this issue by increasing `max_length` or '
                         'modifying the `truncation_strategy`.')

    def __len__(self) -> int:
        return len(self.dataset)


class EncodePreprocessor(RowPreprocessor):

    def __init__(self, template: 'Template'):
        super().__init__()
        self.template = template

    def preprocess(self, row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        return self.template.encode(row, return_length=True)


class AddLengthPreprocessor(EncodePreprocessor):

    def preprocess(self, row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        encoded = super().preprocess(row)
        row['length'] = encoded['length']
        return row


TEMP_DIR_POOL = {}


def get_temporary_cache_files_directory(prefix=None):
    if prefix is None:
        import datasets.config
        prefix = datasets.config.TEMP_CACHE_DIR_PREFIX
    if prefix in TEMP_DIR_POOL:
        TEMP_DIR = TEMP_DIR_POOL[prefix]
    else:
        tmp_dir = os.path.join(get_cache_dir(), 'tmp')
        os.makedirs(tmp_dir, exist_ok=True)
        kwargs = {}
        parameters = inspect.signature(tempfile.TemporaryDirectory.__init__).parameters
        if 'ignore_cleanup_errors' in parameters:
            kwargs['ignore_cleanup_errors'] = True
        TEMP_DIR = tempfile.TemporaryDirectory(prefix=prefix, dir=tmp_dir, **kwargs)
        logger.info(f'create tmp_dir: {TEMP_DIR.name}')
        TEMP_DIR_POOL[prefix] = TEMP_DIR

    return TEMP_DIR.name
