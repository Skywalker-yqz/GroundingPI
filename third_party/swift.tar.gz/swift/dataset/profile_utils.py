# Copyright (c) ModelScope Contributors. All rights reserved.
import os
from typing import Optional

from swift.utils import get_logger

logger = get_logger()


def is_data_profile_enabled(args=None) -> bool:
    if args is not None and getattr(args, 'data_profile', False):
        return True
    env_value = os.environ.get('SWIFT_DATA_PROFILE')
    return env_value is not None and env_value.lower() not in {'0', 'false', 'off', 'no', ''}


def data_profile_log(message: str, *, args=None) -> None:
    if is_data_profile_enabled(args):
        logger.info(f'DATA_PROFILE {message}')


def _safe_dataset_len(dataset) -> Optional[int]:
    if dataset is None:
        return None
    try:
        return len(dataset)
    except Exception:
        return None


def data_profile_describe_dataset(dataset) -> str:
    if dataset is None:
        return 'None'
    dataset_type = dataset.__class__.__name__
    dataset_len = _safe_dataset_len(dataset)
    if dataset_len is None:
        return dataset_type
    return f'{dataset_type}(len={dataset_len})'
