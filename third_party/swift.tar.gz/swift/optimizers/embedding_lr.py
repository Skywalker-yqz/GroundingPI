# Copyright (c) ModelScope Contributors. All rights reserved.
import torch.nn as nn
from transformers import Trainer as HfTrainer

from swift.utils import get_logger
from .base import OptimizerCallback

logger = get_logger()


def _model_use_mtp(model) -> bool:
    if getattr(model, 'use_mtp', False):
        return True
    cfg = getattr(model, 'config', None)
    if cfg is None:
        return False
    tc = getattr(cfg, 'text_config', None)
    if tc is not None and getattr(tc, 'use_mtp', False):
        return True
    return getattr(cfg, 'use_mtp', False)


class EmbeddingLrOptimizerCallback(OptimizerCallback):
    """embed_tokens/lm_head/mtp_heads can use dedicated learning rates.

    - embed_tokens (nn.Embedding) uses args.embedding_lr
    - lm_head uses args.lm_head_lr (if set, otherwise learning_rate)
    - mtp_heads uses args.mtp_lr (if set, otherwise learning_rate)
    - other params use args.learning_rate
    """

    def create_optimizer(self):
        args = self.args
        model = self.trainer.model
        decay_parameters = set(HfTrainer.get_decay_parameter_names(None, model))

        embedding_prefixes = []
        for module_name, module in model.named_modules():
            if isinstance(module, nn.Embedding) and 'embed_tokens' in module_name:
                embedding_prefixes.append(module_name)

        lm_head_param_ids = set()
        mtp_prefixes = ['mtp_heads', 'model.mtp_heads', 'base_model.model.mtp_heads']
        output_embeddings = None
        if hasattr(model, 'get_output_embeddings'):
            try:
                output_embeddings = model.get_output_embeddings()
            except Exception:
                output_embeddings = None
        if output_embeddings is not None:
            for p_ in output_embeddings.parameters(recurse=True):
                lm_head_param_ids.add(id(p_))

        model_arch = getattr(getattr(model, 'model_meta', None), 'model_arch', None)
        lm_head_key = getattr(model_arch, 'lm_head', None) if model_arch is not None else None
        lm_head_prefixes = []
        if lm_head_key:
            lm_head_prefixes.extend([
                lm_head_key,
                f'model.{lm_head_key}',
                f'base_model.model.{lm_head_key}',
            ])

        def _is_embedding_param(param_name: str) -> bool:
            for prefix in embedding_prefixes:
                if param_name == prefix + '.weight' or param_name.startswith(prefix + '.'):
                    return True
            return False

        def _is_lm_head_param(param_name: str, param: nn.Parameter) -> bool:
            if id(param) in lm_head_param_ids:
                return True
            for prefix in lm_head_prefixes:
                if param_name == prefix + '.weight' or param_name.startswith(prefix + '.'):
                    return True
            lm_head_suffixes = (
                '.lm_head.weight', '.lm_head.bias',
                '.embed_out.weight', '.embed_out.bias',
                '.output_layer.weight', '.output_layer.bias',
            )
            return param_name.endswith(lm_head_suffixes)

        def _is_mtp_param(param_name: str) -> bool:
            for prefix in mtp_prefixes:
                if param_name == prefix or param_name.startswith(prefix + '.'):
                    return True
            return False

        use_mtp = _model_use_mtp(model)
        if hasattr(model, 'mtp_heads') and use_mtp:
            mtp_fixed = 0
            for name, param in model.named_parameters():
                if 'mtp_heads' in name and not param.requires_grad:
                    param.requires_grad = True
                    mtp_fixed += 1
            if mtp_fixed:
                logger.info(f'[embedding_lr] Enabled requires_grad for {mtp_fixed} mtp_heads parameters')

        emb_decay, emb_no_decay = [], []
        head_decay, head_no_decay = [], []
        mtp_decay, mtp_no_decay = [], []
        other_decay, other_no_decay = [], []

        lm_head_lr_arg = getattr(args, 'lm_head_lr', None)
        embedding_lr = args.embedding_lr if args.embedding_lr is not None else args.learning_rate
        lm_head_lr = lm_head_lr_arg if lm_head_lr_arg is not None else args.learning_rate
        mtp_lr = args.mtp_lr if args.mtp_lr is not None else args.learning_rate

        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue

            is_embedding = _is_embedding_param(name)
            is_lm_head = _is_lm_head_param(name, param)

            # If embeddings and lm_head share a tied weight, prefer lm_head bucket when lm_head_lr is explicitly set.
            if is_embedding and is_lm_head and lm_head_lr_arg is not None:
                is_embedding = False

            if is_embedding:
                if name in decay_parameters:
                    emb_decay.append(param)
                else:
                    emb_no_decay.append(param)
            elif is_lm_head:
                if name in decay_parameters:
                    head_decay.append(param)
                else:
                    head_no_decay.append(param)
            elif _is_mtp_param(name):
                if name in decay_parameters:
                    mtp_decay.append(param)
                else:
                    mtp_no_decay.append(param)
            else:
                if name in decay_parameters:
                    other_decay.append(param)
                else:
                    other_no_decay.append(param)

        logger.info(f'embedding_lr: {embedding_lr}, lm_head_lr: {lm_head_lr}, mtp_lr: {mtp_lr}, other_lr: {args.learning_rate}')
        logger.info(f'Embedding modules found: {embedding_prefixes}')
        logger.info(f'LM-head prefixes used: {lm_head_prefixes}')
        logger.info(f'MTP prefixes used: {mtp_prefixes}')
        logger.info(f'Embedding params (decay): {len(emb_decay)}, (no_decay): {len(emb_no_decay)}')
        logger.info(f'LM-head params (decay): {len(head_decay)}, (no_decay): {len(head_no_decay)}')
        logger.info(f'MTP params (decay): {len(mtp_decay)}, (no_decay): {len(mtp_no_decay)}')
        logger.info(f'Other params (decay): {len(other_decay)}, (no_decay): {len(other_no_decay)}')

        optimizer_grouped_parameters = []
        if emb_decay:
            optimizer_grouped_parameters.append({
                'params': emb_decay,
                'weight_decay': args.weight_decay,
                'lr': embedding_lr,
                'swift_group_name': 'embedding',
            })
        if emb_no_decay:
            optimizer_grouped_parameters.append({
                'params': emb_no_decay,
                'weight_decay': 0.0,
                'lr': embedding_lr,
                'swift_group_name': 'embedding',
            })
        if head_decay:
            optimizer_grouped_parameters.append({
                'params': head_decay,
                'weight_decay': args.weight_decay,
                'lr': lm_head_lr,
                'swift_group_name': 'lm_head',
            })
        if head_no_decay:
            optimizer_grouped_parameters.append({
                'params': head_no_decay,
                'weight_decay': 0.0,
                'lr': lm_head_lr,
                'swift_group_name': 'lm_head',
            })
        if mtp_decay:
            optimizer_grouped_parameters.append({
                'params': mtp_decay,
                'weight_decay': args.weight_decay,
                'lr': mtp_lr,
                'swift_group_name': 'mtp',
            })
        if mtp_no_decay:
            optimizer_grouped_parameters.append({
                'params': mtp_no_decay,
                'weight_decay': 0.0,
                'lr': mtp_lr,
                'swift_group_name': 'mtp',
            })
        if other_decay:
            optimizer_grouped_parameters.append({
                'params': other_decay,
                'weight_decay': args.weight_decay,
                'lr': args.learning_rate,
                'swift_group_name': 'other',
            })
        if other_no_decay:
            optimizer_grouped_parameters.append({
                'params': other_no_decay,
                'weight_decay': 0.0,
                'lr': args.learning_rate,
                'swift_group_name': 'other',
            })

        optimizer_cls, optimizer_kwargs = HfTrainer.get_optimizer_cls_and_kwargs(args, model)
        return optimizer_cls(optimizer_grouped_parameters, **optimizer_kwargs)
